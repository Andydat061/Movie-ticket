package com.example.final_software.ProjectionManager.QLXuatChieu;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.final_software.DBHelper;
import com.example.final_software.Models.Ghe_XuatChieu;
import com.example.final_software.R;

import java.util.ArrayList;

public class DetailXuatChieuActivity extends AppCompatActivity {
    TextView get_ID, get_NgayChieu, get_TgianBD, get_TGKT, get_PhimChieu, get_RapChieu, get_GiaVe;
    int idphim, idrap, idXuatChieu;
    DBHelper db;
    ListView listView;
    RecyclerView rcv;
    ArrayList<String> seat_char;
    ArrayList<Ghe_XuatChieu> list_seat;
    ListGhe_XuatChieuAdapter ghe_xuatChieuAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_xuat_chieu);
        db = new DBHelper(DetailXuatChieuActivity.this);
        get_ID = findViewById(R.id.detail_xuatchieu_ID);
        get_NgayChieu = findViewById(R.id.detail_xuatchieu_NgayChieu);
        get_TgianBD = findViewById(R.id.detail_xuatchieu_TGBD);
        get_TGKT = findViewById(R.id.detail_xuatchieu_TGKT);
        get_PhimChieu = findViewById(R.id.detail_xuatchieu_PhimChieu);
        get_RapChieu = findViewById(R.id.detail_xuatchieu_RapChieu);
        get_GiaVe = findViewById(R.id.detail_xuatchieu_GiaVe);
        listView = findViewById(R.id.detail_xuatChieu_list_alphabet_seat);
        rcv = findViewById(R.id.list_seat_XuatChieu);
        seat_char = new ArrayList<>();
        list_seat = new ArrayList<>();
        get_setIntent();
        setSeatChar();
        ArrayAdapter char_seat_adapter = new ArrayAdapter(DetailXuatChieuActivity.this, R.layout.item_alpha_seat, seat_char);
        listView.setAdapter(char_seat_adapter);
        ghe_xuatChieuAdapter = new ListGhe_XuatChieuAdapter(this, list_seat);
        rcv.setLayoutManager(new GridLayoutManager(this, 8));
        rcv.setAdapter(ghe_xuatChieuAdapter);
    }
    public void get_setIntent(){
        if(getIntent().hasExtra("idxuatchieu")
                && getIntent().hasExtra("ngaychieu")
                && getIntent().hasExtra("tgbd")
                && getIntent().hasExtra("tgkt")
                && getIntent().hasExtra("rapchieu")
                && getIntent().hasExtra("phimchieu")
                && getIntent().hasExtra("giave")){
            idXuatChieu = getIntent().getIntExtra("idxuatchieu", 0);
            get_ID.setText("ID: "+ idXuatChieu);
            get_NgayChieu.setText("Ngày chiếu: "+ getIntent().getStringExtra("ngaychieu"));
            get_TgianBD.setText("Thời gian bắt đầu: "+ getIntent().getStringExtra("tgbd"));
            get_TGKT.setText("Thời gian kết thúc: "+ getIntent().getStringExtra("tgkt"));
            get_GiaVe.setText("Giá vé: " + getIntent().getIntExtra("giave", 0));
            idphim = getIntent().getIntExtra("phimchieu", 0);
            idrap = getIntent().getIntExtra("rapchieu", 0);
            Cursor cursor = db.get_Phim_For_XuatChieu(idphim);
            if(cursor != null){
                while (cursor.moveToNext()){
                    get_PhimChieu.setText("Phim chiếu: " +cursor.getString(0));
                }
                cursor.close();
            }
            cursor = db.get_Rap_ForXuatChieu(idrap);
            if(cursor != null){
                while (cursor.moveToNext()){
                    get_RapChieu.setText("Rạp chiếu: " +cursor.getString(0));
                }
                cursor.close();
            }
        }
        else {
            Toast.makeText(this, "No data....", Toast.LENGTH_SHORT).show();
        }
    }
    public void setSeatChar(){
        Cursor cursor = db.get_ALL_Ghe_XuatChieu(idXuatChieu);
        if(cursor != null){
            if(cursor.getCount() % 8 == 0){
                int soluonghang = cursor.getCount() / 8;
                for(int i = 0; i< soluonghang; i++){
                    seat_char.add(Character.toString((char)(i + 65)));
                }
                while(cursor.moveToNext()){
                    Ghe_XuatChieu gheXuatChieu = new Ghe_XuatChieu(cursor.getInt(0),
                            cursor.getInt(1),
                            cursor.getInt(2),
                            cursor.getString(3));
                    list_seat.add(gheXuatChieu);
                }
                cursor.close();
            }
            else{
                int soluonghang = cursor.getCount() / 8 + 1;
                for(int i = 0; i< soluonghang; i++){
                    seat_char.add(Character.toString((char)(i + 65)));
                }
                while(cursor.moveToNext()){
                    Ghe_XuatChieu gheXuatChieu = new Ghe_XuatChieu(cursor.getInt(0),
                            cursor.getInt(1),
                            cursor.getInt(2),
                            cursor.getString(3));
                    list_seat.add(gheXuatChieu);
                }
                cursor.close();
            }
        }
    }
}