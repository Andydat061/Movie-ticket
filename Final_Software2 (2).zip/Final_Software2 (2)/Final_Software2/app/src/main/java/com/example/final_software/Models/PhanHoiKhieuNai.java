package com.example.final_software.Models;

public class PhanHoiKhieuNai {
    private int maPhanHoi;
    private String tieuDe;
    private String dichVu;
    private String phanHoiCuThe;
    private String ngayPhanHoi; // Sử dụng String cho datetime
    private int khieuNaiID;
    private int nguoiPH;

    public PhanHoiKhieuNai(){}
    public PhanHoiKhieuNai(int maPhanHoi, String tieuDe, String dichVu, String phanHoiCuThe, String ngayPhanHoi, int khieuNaiID, int nguoiPH) {
        this.maPhanHoi = maPhanHoi;
        this.tieuDe = tieuDe;
        this.dichVu = dichVu;
        this.phanHoiCuThe = phanHoiCuThe;
        this.ngayPhanHoi = ngayPhanHoi;
        this.khieuNaiID = khieuNaiID;
        this.nguoiPH = nguoiPH;
    }

    // Getter and Setter methods
    public int getMaPhanHoi() {
        return maPhanHoi;
    }

    public void setMaPhanHoi(int maPhanHoi) {
        this.maPhanHoi = maPhanHoi;
    }

    public String getTieuDe() {
        return tieuDe;
    }

    public void setTieuDe(String tieuDe) {
        this.tieuDe = tieuDe;
    }

    public String getDichVu() {
        return dichVu;
    }

    public void setDichVu(String dichVu) {
        this.dichVu = dichVu;
    }

    public String getPhanHoiCuThe() {
        return phanHoiCuThe;
    }

    public void setPhanHoiCuThe(String phanHoiCuThe) {
        this.phanHoiCuThe = phanHoiCuThe;
    }

    public String getNgayPhanHoi() {
        return ngayPhanHoi;
    }

    public void setNgayPhanHoi(String ngayPhanHoi) {
        this.ngayPhanHoi = ngayPhanHoi;
    }

    public int getKhieuNaiID() {
        return khieuNaiID;
    }

    public void setKhieuNaiID(int khieuNaiID) {
        this.khieuNaiID = khieuNaiID;
    }

    public int getNguoiPH() {
        return nguoiPH;
    }

    public void setNguoiPH(int nguoiPH) {
        this.nguoiPH = nguoiPH;
    }

    @Override
    public String toString() {
        return "PhanHoiKhieuNai{" +
                "maPhanHoi=" + maPhanHoi +
                ", tieuDe='" + tieuDe + '\'' +
                ", dichVu='" + dichVu + '\'' +
                ", phanHoiCuThe='" + phanHoiCuThe + '\'' +
                ", ngayPhanHoi='" + ngayPhanHoi + '\'' +
                ", khieuNaiID=" + khieuNaiID +
                ", nguoiPH=" + nguoiPH +
                '}';
    }
}
