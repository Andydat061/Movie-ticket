package com.example.final_software.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.final_software.CustomerServiceAgent.ChiTietKhieuNaiActivity;
import com.example.final_software.DBHelper;
import com.example.final_software.Models.KhieuNai;
import com.example.final_software.R;

import java.util.List;

public class KhieuNaiAdapter extends RecyclerView.Adapter<KhieuNaiAdapter.ViewHolder> {

    private List<KhieuNai> khieuNaiList;
    private Listener listener;
    private Context context;

    public KhieuNaiAdapter(List<KhieuNai> khieuNaiList, Listener listener, Context context) {
        this.khieuNaiList = khieuNaiList;
        this.listener = listener;
        this.context = context; // Save the context for use in Intent
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_khieu_nai, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        KhieuNai khieuNai = khieuNaiList.get(position);
        holder.textViewMaKhieuNai.setText(String.valueOf(khieuNai.getMaKhieuNai()));
        holder.textViewTenNguoiDung.setText("Người dùng " + khieuNai.getNguoiKN());

        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onItemClick(khieuNai);
            }

            // Chuyển hướng sang ChiTietKhieuNaiActivity với dữ liệu của khiếu nại được chọn
            Intent intent = new Intent(context, ChiTietKhieuNaiActivity.class);
            intent.putExtra("MA_KHIEU_NAI", khieuNai.getMaKhieuNai()); // Truyền dữ liệu qua Intent
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return khieuNaiList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView textViewMaKhieuNai;
        TextView textViewTenNguoiDung;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewMaKhieuNai = itemView.findViewById(R.id.textViewMaKhieuNai);
            textViewTenNguoiDung = itemView.findViewById(R.id.textViewTenNguoiDung);
        }
    }

    public interface Listener {
        void onItemClick(KhieuNai khieuNai);
    }
}