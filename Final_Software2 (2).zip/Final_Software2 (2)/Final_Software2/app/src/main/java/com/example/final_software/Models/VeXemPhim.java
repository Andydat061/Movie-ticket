package com.example.final_software.Models;

public class VeXemPhim {
    public int IDVe;
    public int TaiKhoanID;
    public int GiaVe;
    public String NgayMua;
    public String TrangThaiVe;

    public VeXemPhim(int IDVe, int taiKhoanID, int giaVe, String ngayMua, String trangThaiVe) {
        this.IDVe = IDVe;
        TaiKhoanID = taiKhoanID;
        GiaVe = giaVe;
        NgayMua = ngayMua;
        TrangThaiVe = trangThaiVe;
    }

    public VeXemPhim(int taiKhoanID, int giaVe, String ngayMua, String trangThaiVe) {
        TaiKhoanID = taiKhoanID;
        GiaVe = giaVe;
        NgayMua = ngayMua;
        TrangThaiVe = trangThaiVe;
    }
}
