package com.example.final_software.Customer.BookingTicket;

import static androidx.core.app.ActivityCompat.recreate;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.example.final_software.Customer.BookingTicket.Adapter.Ghe_XuatChieu_CTM_Adapter;
import com.example.final_software.DBHelper;
import com.example.final_software.Models.Ghe_XuatChieu;
import com.example.final_software.ProjectionManager.QLXuatChieu.DetailXuatChieuActivity;
import com.example.final_software.ProjectionManager.QLXuatChieu.ListGhe_XuatChieuAdapter;
import com.example.final_software.R;

import java.util.ArrayList;

public class Ghe_XuatChieu_CTMActivity extends AppCompatActivity {
    // Chưa lấy đc list ghế của người đặt và tổng tiền (Có thể dùng shared preferences)
    int IDXuatchieu, GiaVe, TongTien;
    String ngayChieu, tgianChieu, chuoiGhe_DaChon, listIDGhe, diadiem, tenPhim;
    ArrayList<String> seat_char;
    ArrayList<Ghe_XuatChieu> list_seat;
    ListView listView;
    RecyclerView rcv;
    Ghe_XuatChieu_CTM_Adapter ghe_xuatChieuAdapter;
    TextView txt_diadiemchieu, txt_ngaychieu, txt_tgianchieu, txt_tenphim, txt_gheDaChon, txt_TongTien, ic_back;
    Button btn_accept_booking;
    ArrayList<String> list_maGhe;


    DBHelper db = new DBHelper(Ghe_XuatChieu_CTMActivity.this);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_xuat_chieu_ctmactivity);
        seat_char = new ArrayList<>();
        list_seat = new ArrayList<>();
        rcv = findViewById(R.id.list_seat_XuatChieu_ctm);
        listView = findViewById(R.id.list_alphabet_seat_ctm);
        txt_ngaychieu = findViewById(R.id.list_ghe_xuatchieu_ngaychieu);
        txt_tgianchieu = findViewById(R.id.list_ghe_xuatchieu_giochieu);
        txt_gheDaChon = findViewById(R.id.list_ghe_xuatchieu_soluongghe);
        txt_TongTien = findViewById(R.id.list_ghe_xuatchieu_giave);
        ic_back = findViewById(R.id.ic_back_detail_ghe_xuatchieu_ctm);
        txt_diadiemchieu = findViewById(R.id.list_ghe_xuatchieu_diadiemchieu);
        txt_tenphim = findViewById(R.id.list_ghe_xuatchieu_tenphim);
        btn_accept_booking = findViewById(R.id.btn_accept_booking);
        chuoiGhe_DaChon = "";
        TongTien = 0;
        list_maGhe = new ArrayList<>();
        get_setIntent();
        setSeatChar();
        txt_ngaychieu.setText(ngayChieu);
        txt_tgianchieu.setText(tgianChieu);
        ArrayAdapter char_seat_adapter = new ArrayAdapter(Ghe_XuatChieu_CTMActivity.this, R.layout.item_alpha_seat, seat_char);
        listView.setAdapter(char_seat_adapter);
        ghe_xuatChieuAdapter = new Ghe_XuatChieu_CTM_Adapter(this, list_seat, GiaVe, this::reLoadBar);
        rcv.setLayoutManager(new GridLayoutManager(this, 8));
        rcv.setAdapter(ghe_xuatChieuAdapter);
        SharedPreferences sharedPreferences = Ghe_XuatChieu_CTMActivity.this.getSharedPreferences("BookingTicket", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.remove("ListGheNgoi");
        editor.remove("ListIDGhe");
        editor.remove("TongTien");
        setTenDiaDiemAndTenPhim();
        ic_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        btn_accept_booking.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent a = new Intent(Ghe_XuatChieu_CTMActivity.this, AcceptBookingActivity.class);
                a.putExtra("idxuatchieu", IDXuatchieu);
                a.putExtra("tongtien", TongTien);
                a.putExtra("tendiadiem", diadiem);
                a.putExtra("tenphim", tenPhim);
                a.putExtra("ngaychieu", ngayChieu);
                a.putExtra("thoigianchieu", tgianChieu);
                startActivity(a);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
    }
    public void reLoadBar(){
        SharedPreferences sharedPreferences = Ghe_XuatChieu_CTMActivity.this.getSharedPreferences("BookingTicket", MODE_PRIVATE);
        TongTien = sharedPreferences.getInt("TongTien", 0);
        chuoiGhe_DaChon = sharedPreferences.getString("ListGheNgoi", "");
        listIDGhe = sharedPreferences.getString("ListIDGhe", "");
        txt_TongTien.setText("Tổng tiền: "+ TongTien + " đ");
        txt_gheDaChon.setText("Chọn "+ (chuoiGhe_DaChon.split(",").length - 1) + " ghế: "+ chuoiGhe_DaChon);
    }
    public void get_setIntent(){
        if(getIntent().hasExtra("idxuatchieu")
                && getIntent().hasExtra("giave")
                && getIntent().hasExtra("ngaychieu")
                && getIntent().hasExtra("thoigianchieu")){
            IDXuatchieu = getIntent().getIntExtra("idxuatchieu", 0);
            GiaVe = getIntent().getIntExtra("giave", 0);
            ngayChieu = getIntent().getStringExtra("ngaychieu");
            tgianChieu = getIntent().getStringExtra("thoigianchieu");
        }
    }
    private void setSeatChar(){
        Cursor cursor = db.get_ALL_Ghe_XuatChieu(IDXuatchieu);
        if(cursor != null){
            if(cursor.getCount() % 8 == 0){
                int soluonghang = cursor.getCount() / 8;
                for(int i = 0; i< soluonghang; i++){
                    seat_char.add(Character.toString((char)(i + 65)));
                }
                while(cursor.moveToNext()){
                    Ghe_XuatChieu gheXuatChieu = new Ghe_XuatChieu(cursor.getInt(0),
                            cursor.getInt(1),
                            cursor.getInt(2),
                            cursor.getString(3));
                    list_seat.add(gheXuatChieu);
                }
                cursor.close();
            }
            else{
                int soluonghang = cursor.getCount() / 8 + 1;
                for(int i = 0; i< soluonghang; i++){
                    seat_char.add(Character.toString((char)(i + 65)));
                }
                while(cursor.moveToNext()){
                    Ghe_XuatChieu gheXuatChieu = new Ghe_XuatChieu(cursor.getInt(0),
                            cursor.getInt(1),
                            cursor.getInt(2),
                            cursor.getString(3));
                    list_seat.add(gheXuatChieu);
                }
                cursor.close();
            }
        }
    }
    private void setTenDiaDiemAndTenPhim(){
        Cursor cursor = db.getTenDiaDiemAndTenPhim_IDXuatChieu(IDXuatchieu);
        cursor.moveToNext();
        diadiem = cursor.getString(1);
        tenPhim = cursor.getString(0);
        if(tenPhim.length() > 35){
            txt_tenphim.setText(tenPhim.substring(0,35) + "...");
        } else if (diadiem.length() > 30) {
            txt_diadiemchieu.setText(diadiem.substring(0,30) + "...");
        } else{
            txt_tenphim.setText(tenPhim);
            txt_diadiemchieu.setText(diadiem);
        }
        cursor.close();
    }
}