package com.example.final_software.ProjectionManager.QLTheLoai_PhimChieu;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.final_software.R;

import java.util.ArrayList;

public class CategoryAdapter extends RecyclerView.Adapter<CategoryAdapter.MyViewHolder> {

    private Context context;
    Activity activity;

    ArrayList<String> theloai_id, theloai_ten, theloai_mota;



    public CategoryAdapter(Activity activity,
                           Context context,
                           ArrayList theloai_id,
                           ArrayList theloai_ten,
                           ArrayList theloai_mota) {
        this.activity=activity;
        this.context=context;
        this.theloai_id=theloai_id;
        this.theloai_ten=theloai_ten;
        this.theloai_mota=theloai_mota;

    }

    public CategoryAdapter(Category activity, ArrayList<String> theloaiId, ArrayList<String> theloaiTen) {
    }

    @NonNull
    @Override
    public CategoryAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.my_row, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CategoryAdapter.MyViewHolder holder, @SuppressLint("RecyclerView") final int position) {


        holder.theloai_id_text.setText(String.valueOf(theloai_id.get(position)));
        holder.theloai_ten_text.setText(String.valueOf(theloai_ten.get(position)));

        holder.mainLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ArrayList<String> list = new ArrayList<String>();
                Intent intent = new Intent(context, UpdateCategory.class);
                intent.putExtra("idtheloai", String.valueOf(theloai_id.get(position)));
                intent.putExtra("tentheloai", String.valueOf(theloai_ten.get(position)));
                intent.putExtra("mota", String.valueOf(theloai_mota.get(position)));
                activity.startActivityForResult(intent, 1);

            }
        });
    }

    @Override
    public int getItemCount() {
        return theloai_id.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView theloai_id_text, theloai_ten_text;
        LinearLayout mainLayout;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            theloai_id_text = itemView.findViewById(R.id.theloai_id_text);
            theloai_ten_text = itemView.findViewById(R.id.theloai_ten_text);
            mainLayout = itemView.findViewById(R.id.mainLayout);
        }
    }
}
