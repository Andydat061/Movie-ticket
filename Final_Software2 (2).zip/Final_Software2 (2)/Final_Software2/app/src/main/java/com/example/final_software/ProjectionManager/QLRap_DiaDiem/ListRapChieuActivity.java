package com.example.final_software.ProjectionManager.QLRap_DiaDiem;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;

import com.example.final_software.Models.RapChieu;
import com.example.final_software.R;

import java.util.ArrayList;

public class ListRapChieuActivity extends AppCompatActivity {
    ArrayList<RapChieu> arrRapChieu;
    Button btn_gotoAddRapChieu;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_rap_chieu);
    }
}