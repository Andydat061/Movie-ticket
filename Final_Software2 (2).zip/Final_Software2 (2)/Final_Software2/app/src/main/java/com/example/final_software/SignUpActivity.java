package com.example.final_software;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.final_software.Models.TaiKhoanKhachHang;

public class SignUpActivity extends AppCompatActivity {
    EditText name_sig,username_sig,password_sig,birthday_sig,email_sig,phone_sig,repassword_sig;

    Button btn_signup;
    DBHelper dbHelper;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        name_sig=findViewById(R.id.name_sig);
        username_sig=findViewById(R.id.username_sig);
        password_sig=findViewById(R.id.password_sig);
        repassword_sig=findViewById(R.id.repassword_sig);
        birthday_sig=findViewById(R.id.birthday_sig);
        email_sig=findViewById(R.id.email_sig);
        phone_sig=findViewById(R.id.phone_sig);
        btn_signup=findViewById(R.id.btn_signup);
        dbHelper= new DBHelper(this);
        btn_signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(SignUpActivity.this, LogInActivity.class);
                startActivity(intent);
            }
        });
            btn_signup.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    String strname_sig = name_sig.getText().toString();
                    String strusername_sig = username_sig.getText().toString();
                    String strpassword_sig = password_sig.getText().toString();
                    String strrepassword_sig = repassword_sig.getText().toString();
                    String strbirthday_sig = birthday_sig.getText().toString();
                    String stremail_sig = email_sig.getText().toString();
                    String strphone_sig = phone_sig.getText().toString();

                    if(strname_sig.equals("") || strusername_sig.equals("") ||
                            strpassword_sig.equals("") || strrepassword_sig.equals("") || strbirthday_sig.equals("") ||
                            stremail_sig.equals("") || strphone_sig.equals("") )
                    {
                        Toast.makeText(SignUpActivity.this, "Vui lòng không để trống thông tin", Toast.LENGTH_SHORT).show();
                    } else {
                        if (strpassword_sig.equals(repassword_sig)) {

                            if (dbHelper.checkUsername(strusername_sig)) {
                                Toast.makeText(SignUpActivity.this, "Tài khoản đã được đăng ký", Toast.LENGTH_SHORT).show();
                                return;
                            }boolean registeredsuccess = dbHelper.addTaiKhoan(strusername_sig,strpassword_sig,strname_sig,strrepassword_sig,strbirthday_sig,stremail_sig,strphone_sig);
                            if (registeredsuccess)
                                Toast.makeText(SignUpActivity.this, "Đăng ký thành công", Toast.LENGTH_SHORT).show();
                            else
                                Toast.makeText(SignUpActivity.this, "Đăng ký thất bại", Toast.LENGTH_SHORT).show();
                        }
                        else {
                            Toast.makeText(SignUpActivity.this,"Mật khẩu không trùng khớp", Toast.LENGTH_SHORT).show();
                        }
                    }

                }
            });
    }
}