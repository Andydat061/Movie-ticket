package com.example.final_software.CustomerServiceAgent;

import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.example.final_software.DBHelper;
import com.example.final_software.Models.PhanHoiKhieuNai;
import com.example.final_software.R;

public class ChiTietPhanHoiActivity extends AppCompatActivity {

    private TextView textViewMoTaChiTiet, textViewPhanHoi, textViewNgayPhanHoi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_chi_tiet_phan_hoi);

        // Ánh xạ các thành phần giao diện
        textViewMoTaChiTiet = findViewById(R.id.textViewMoTaChiTiet);
        textViewPhanHoi = findViewById(R.id.textViewPhanHoi);
        textViewNgayPhanHoi = findViewById(R.id.textViewNgayPhanHoi);


        // Lấy dữ liệu từ Intent
        int maKhieuNai = getIntent().getIntExtra("MA_KHIEU_NAI", -1);
        String chiTiet = getIntent().getStringExtra("CHI_TIET");

        DBHelper dbHelper = new DBHelper(this);
        PhanHoiKhieuNai phanHoi = dbHelper.getPhanHoiByKhieuNaiID(maKhieuNai);
        // Hiển thị thông tin trên giao diện
        if (maKhieuNai != -1 && chiTiet != null && phanHoi != null) {
            textViewMoTaChiTiet.setText(chiTiet);
            textViewPhanHoi.setText(phanHoi.getPhanHoiCuThe());
            textViewNgayPhanHoi.setText(phanHoi.getNgayPhanHoi());
        } else {
            Toast.makeText(this, "Thông tin không đầy đủ", Toast.LENGTH_SHORT).show();
        }
    }
}
