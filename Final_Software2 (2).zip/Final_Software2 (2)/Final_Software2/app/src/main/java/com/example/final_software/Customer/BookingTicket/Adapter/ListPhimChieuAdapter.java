package com.example.final_software.Customer.BookingTicket.Adapter;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.final_software.Customer.BookingTicket.Detail_PhimChieu_BookingTicketActivity;
import com.example.final_software.Models.PhimChieu;
import com.example.final_software.ProjectionManager.QLXuatChieu.ListGhe_XuatChieuAdapter;
import com.example.final_software.R;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;

public class ListPhimChieuAdapter extends RecyclerView.Adapter<ListPhimChieuAdapter.MyViewHolder>{
    ArrayList<PhimChieu> arrPhimChieu;
    Context context;

    public ListPhimChieuAdapter(Context context,ArrayList<PhimChieu> arrPhimChieu) {
        this.arrPhimChieu = arrPhimChieu;
        this.context = context;
    }

    @NonNull
    @Override
    public ListPhimChieuAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_phimchieu, parent, false);
        return new ListPhimChieuAdapter.MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ListPhimChieuAdapter.MyViewHolder holder, int position) {
        if(arrPhimChieu.get(position).AnhQC == null){
            holder.anhQC.setImageResource(R.drawable.tt_conan);
            holder.main_layout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent a = new Intent(context, Detail_PhimChieu_BookingTicketActivity.class);
                    a.putExtra("idphim", arrPhimChieu.get(position).IDPhim);
                    a.putExtra("tenphim", arrPhimChieu.get(position).TenPhim);
                    holder.itemView.getContext().startActivity(a);
                }
            });
        }
        else{
            holder.anhQC.setImageBitmap(arrPhimChieu.get(position).AnhQC);
            holder.main_layout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ByteArrayOutputStream stream = new ByteArrayOutputStream();
                    arrPhimChieu.get(position).AnhQC.compress(Bitmap.CompressFormat.JPEG, 50, stream);
                    byte[] imageByte = stream.toByteArray();
                    Intent a = new Intent(context, Detail_PhimChieu_BookingTicketActivity.class);
                    a.putExtra("idphim", arrPhimChieu.get(position).IDPhim);
                    a.putExtra("anhqc", imageByte);
                    a.putExtra("tenphim", arrPhimChieu.get(position).TenPhim);
                    holder.itemView.getContext().startActivity(a);
                }
            });
        }
        holder.txt_tenPhim.setText(arrPhimChieu.get(position).TenPhim + "");
    }

    @Override
    public int getItemCount() {
        return arrPhimChieu == null ? 0 : arrPhimChieu.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        ImageView anhQC;
        TextView txt_tenPhim;
        LinearLayout main_layout;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            main_layout = itemView.findViewById(R.id.list_phimChieu_main_layout);
            anhQC = itemView.findViewById(R.id.get_image_list_phimchieu);
            txt_tenPhim = itemView.findViewById(R.id.get_name_list_phimchieu);
        }
    }
}
