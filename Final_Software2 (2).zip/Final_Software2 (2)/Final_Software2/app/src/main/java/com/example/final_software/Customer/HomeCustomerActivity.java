package com.example.final_software.Customer;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.MenuItem;

import com.example.final_software.Customer.FragmentHome.AccountCustomerFragment;
import com.example.final_software.Customer.FragmentHome.HomeCustomerFragment;
import com.example.final_software.Customer.FragmentHome.SearchCustomerFragment;
import com.example.final_software.ProjectionManager.FragmentMain.ListDiaDiemChieuFragment;
import com.example.final_software.ProjectionManager.FragmentMain.ListPhimChieuFragment;
import com.example.final_software.ProjectionManager.FragmentMain.ListSanPhamFragment;
import com.example.final_software.ProjectionManager.FragmentMain.ListTheLoaiPhimFragment;
import com.example.final_software.ProjectionManager.FragmentMain.ListXuatChieuFragment;
import com.example.final_software.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;

public class HomeCustomerActivity extends AppCompatActivity {
    BottomNavigationView bottom_nav;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_customer);
        bottom_nav = findViewById(R.id.bottom_nav_ctm);
        setFragment(new HomeCustomerFragment());
        bottom_nav.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                if(item.getItemId() == R.id.btm_nav_home){
                    setFragment(new HomeCustomerFragment());
                    return true;
                }
                if(item.getItemId() == R.id.btm_nav_search){
                    setFragment(new SearchCustomerFragment());
                    return true;
                }
                if(item.getItemId() == R.id.btm_nav_account){
                    setFragment(new AccountCustomerFragment());
                    return true;
                }
                return false;
            }
        });
    }
    protected  void setFragment(Fragment fragment){
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.fragmentContainerView_ctm, fragment);
        fragmentTransaction.commit();
    }
}