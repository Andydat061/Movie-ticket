package com.example.final_software.ProjectionManager.FragmentMain;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import com.example.final_software.DBHelper;
import com.example.final_software.Models.DiaDiemChieu;
import com.example.final_software.Models.Movie;
import com.example.final_software.ProjectionManager.QLRap_DiaDiem.CreateDiaDiemActivity;
import com.example.final_software.ProjectionManager.QLRap_DiaDiem.ListDiaDiemAdapter;
import com.example.final_software.ProjectionManager.QLTheLoai_PhimChieu.PhimChieu.CreateMovieActivity;
import com.example.final_software.ProjectionManager.QLTheLoai_PhimChieu.PhimChieu.ListPhimChieuAdapter;
import com.example.final_software.R;

import java.util.ArrayList;


public class ListDiaDiemChieuFragment extends Fragment {
    Button gotoAdd;
    DBHelper db;
    RecyclerView recyclerView;
    ArrayList<DiaDiemChieu> arrDiaDiem;
    ListDiaDiemAdapter listDiaDiemAdapter;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        Toolbar actionBar = (Toolbar) getActivity().findViewById(R.id.materialToolbar_pm);
        actionBar.setTitle("Danh sách địa điểm chiếu");
        actionBar.setBackgroundColor(Color.WHITE);
        ((AppCompatActivity) getActivity()).setSupportActionBar(actionBar);
        return inflater.inflate(R.layout.fragment_list_dia_diem_chieu, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        recyclerView = view.findViewById(R.id.rcv_pjm_DiaDiemChieu);
        arrDiaDiem = new ArrayList<>();
        db = new DBHelper(getActivity());
        gotoAdd = view.findViewById(R.id.btn_goto_addDiaDiem);
        store_data_to_list();
        listDiaDiemAdapter = new ListDiaDiemAdapter(getActivity(), arrDiaDiem);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false));
        recyclerView.setAdapter(listDiaDiemAdapter);
        gotoAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent a = new Intent(getActivity(), CreateDiaDiemActivity.class);
                startActivity(a);
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        arrDiaDiem = new ArrayList<>();
        db = new DBHelper(getActivity());
        store_data_to_list();
        listDiaDiemAdapter = new ListDiaDiemAdapter(getActivity(), arrDiaDiem);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false));
        recyclerView.setAdapter(listDiaDiemAdapter);
    }

    void store_data_to_list(){
        Cursor cursor = db.getAllDiaDiem();
        if(cursor == null)
            Toast.makeText(getActivity(), "No data.", Toast.LENGTH_SHORT).show();
        else{
            while(cursor.moveToNext()){
                DiaDiemChieu bookModel = new DiaDiemChieu(cursor.getInt(0),
                        cursor.getString(1));
                arrDiaDiem.add(bookModel);
            }
            cursor.close();
        }
    }
}