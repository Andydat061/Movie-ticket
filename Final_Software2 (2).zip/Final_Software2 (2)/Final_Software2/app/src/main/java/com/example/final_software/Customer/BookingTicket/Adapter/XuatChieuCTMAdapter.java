package com.example.final_software.Customer.BookingTicket.Adapter;

import android.content.Context;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.final_software.DBHelper;
import com.example.final_software.Models.DiaDiemChieu;
import com.example.final_software.Models.XuatChieu;
import com.example.final_software.R;

import java.util.ArrayList;

public class XuatChieuCTMAdapter extends RecyclerView.Adapter<XuatChieuCTMAdapter.MyViewHolder>{
    Context context;
    ArrayList<DiaDiemChieu> arrDiaDiem;
    int IDPhim;
    DBHelper db;

    public XuatChieuCTMAdapter(Context context, ArrayList<DiaDiemChieu> arrDiaDiem, int IDPhim) {
        this.context = context;
        this.arrDiaDiem = arrDiaDiem;
        this.IDPhim = IDPhim;
    }

    @NonNull
    @Override
    public XuatChieuCTMAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_xuatchieu, parent, false);
        return new XuatChieuCTMAdapter.MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull XuatChieuCTMAdapter.MyViewHolder holder, int position) {
        holder.tendiadiem.setText(arrDiaDiem.get(position).TenDiaDiem);
        int IDDiaDiem = arrDiaDiem.get(position).IDDiaDiem;
        Cursor cursor = db.getXuatChieu_IDDiaDiem(IDDiaDiem, IDPhim);
        ArrayList<XuatChieu> listXuatChieu = new ArrayList<>();
        if(cursor.getCount() != 0){
            while (cursor.moveToNext()){
                XuatChieu xuatChieu = new XuatChieu(cursor.getInt(0),
                        cursor.getString(1),
                        cursor.getString(2),
                        cursor.getString(3),
                        cursor.getInt(4),
                        cursor.getInt(5),
                        cursor.getInt(6));
                listXuatChieu.add(xuatChieu);
            }
        }
        holder.rcv.setLayoutManager(new LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false));
        GioChieu_XuatChieuAdapter adapter = new GioChieu_XuatChieuAdapter(context, listXuatChieu);
        holder.rcv.setAdapter(adapter);
    }
    @Override
    public int getItemCount() {
        return arrDiaDiem == null ? 0 : arrDiaDiem.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        RecyclerView rcv;
        TextView tendiadiem;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            rcv = itemView.findViewById(R.id.rcv_ListXuatChieu_Diadiemchieu);
            tendiadiem = itemView.findViewById(R.id.txt_tendiadiem_xuatchieu);
            db = new DBHelper(context);
        }
    }
}
