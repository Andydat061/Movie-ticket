package com.example.final_software.CustomerServiceAgent;

import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.DividerItemDecoration;

import com.example.final_software.Adapter.KhieuNaiAdapter;
import com.example.final_software.DBHelper;
import com.example.final_software.Models.KhieuNai;
import com.example.final_software.R;

import java.util.ArrayList;
import java.util.List;

public class KhieuNaiActivity extends AppCompatActivity implements KhieuNaiAdapter.Listener {

    private RecyclerView recyclerView;
    private KhieuNaiAdapter khieuNaiAdapter;
    private DBHelper dbHelper;
    private List<KhieuNai> khieuNaiList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_khieu_nai);

        recyclerView = findViewById(R.id.recyclerViewKhieuNai);
        recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));

        dbHelper = new DBHelper(this);

        // Load danh sách khiếu nại từ database
        khieuNaiList = dbHelper.getAllKhieuNai(); // Phương thức này cần được implement trong DBHelper

        khieuNaiAdapter = new KhieuNaiAdapter(khieuNaiList, this, this);

        recyclerView.setAdapter(khieuNaiAdapter);

        // Thêm phân cách giữa các item
        recyclerView.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));


        // Thiết lập tiêu đề cho ActionBar
        if (getSupportActionBar() != null) {

            getSupportActionBar().setTitle("Danh sách khiếu nại");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
    }

    @Override
    public void onItemClick(KhieuNai khieuNai) {

//        Toast.makeText(this, "Mã Khiếu Nại: " + khieuNai.getMaKhieuNai() + "\nTên Người Dùng: " + khieuNai.getNguoiKN(), Toast.LENGTH_SHORT).show();
    }
}
