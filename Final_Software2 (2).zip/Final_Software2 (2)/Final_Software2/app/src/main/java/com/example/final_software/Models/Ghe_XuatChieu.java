package com.example.final_software.Models;

public class Ghe_XuatChieu {
    public int IDGhe_XuatChieu;
    public int GheID;
    public int XuatChieuID;
    public String TrangThaiGhe;

    public Ghe_XuatChieu(int IDGhe_XuatChieu, int gheID, int xuatChieuID, String trangThaiGhe) {
        this.IDGhe_XuatChieu = IDGhe_XuatChieu;
        GheID = gheID;
        XuatChieuID = xuatChieuID;
        TrangThaiGhe = trangThaiGhe;
    }

    public Ghe_XuatChieu(int gheID, int xuatChieuID, String trangThaiGhe) {
        GheID = gheID;
        XuatChieuID = xuatChieuID;
        TrangThaiGhe = trangThaiGhe;
    }
}
