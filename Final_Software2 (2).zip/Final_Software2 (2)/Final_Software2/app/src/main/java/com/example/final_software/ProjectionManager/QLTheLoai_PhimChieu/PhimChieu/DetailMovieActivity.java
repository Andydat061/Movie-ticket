package com.example.final_software.ProjectionManager.QLTheLoai_PhimChieu.PhimChieu;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.final_software.R;

public class DetailMovieActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_movie);
    }
}