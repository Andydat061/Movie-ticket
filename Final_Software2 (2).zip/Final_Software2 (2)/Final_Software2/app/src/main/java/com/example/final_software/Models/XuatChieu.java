package com.example.final_software.Models;

import java.sql.Date;
import java.sql.Time;

public class XuatChieu {
    public int IDXuatChieu;
    public String NgayChieu;
    public String ThoiGianBatDau;
    public String ThoiGianKetThuc;
    public int RapChieu;
    public int PhimChieu;
    public int GiaVe;

    public XuatChieu(int IDXuatChieu, String ngayChieu, String thoiGianBatDau, String thoiGianKetThuc, int rapChieu, int phimChieu,int GiaVe) {
        this.IDXuatChieu = IDXuatChieu;
        NgayChieu = ngayChieu;
        ThoiGianBatDau = thoiGianBatDau;
        ThoiGianKetThuc = thoiGianKetThuc;
        RapChieu = rapChieu;
        PhimChieu = phimChieu;
        this.GiaVe = GiaVe;
    }

    public XuatChieu(String ngayChieu, String thoiGianBatDau, String thoiGianKetThuc, int rapChieu, int phimChieu, int giaVe) {
        NgayChieu = ngayChieu;
        ThoiGianBatDau = thoiGianBatDau;
        ThoiGianKetThuc = thoiGianKetThuc;
        RapChieu = rapChieu;
        PhimChieu = phimChieu;
        GiaVe = giaVe;
    }
}
