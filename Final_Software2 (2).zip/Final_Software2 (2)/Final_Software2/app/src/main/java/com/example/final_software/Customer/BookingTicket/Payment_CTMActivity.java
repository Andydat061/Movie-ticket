package com.example.final_software.Customer.BookingTicket;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.final_software.Customer.HomeCustomerActivity;
import com.example.final_software.DBHelper;
import com.example.final_software.Models.CT_VeXemPhim;
import com.example.final_software.Models.VeXemPhim;
import com.example.final_software.R;

import java.time.LocalDateTime;
import java.util.ArrayList;

public class Payment_CTMActivity extends AppCompatActivity {
    Button btn_success, btn_failed;
    ArrayList<Integer> listIDGhe;
    String listGhe;
    int TongTien, IDTaiKhoan;
    DBHelper db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment_ctmactivity);
        btn_success = findViewById(R.id.btn_payment_success);
        btn_failed= findViewById(R.id.btn_payment_failed);
        db = new DBHelper(Payment_CTMActivity.this);
        listIDGhe = new ArrayList<>();
        get_set_Variable();
        btn_success.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                VeXemPhim veXemPhim = new VeXemPhim(IDTaiKhoan, TongTien, LocalDateTime.now().toString(), "Đã thanh toán");
                db.addVeXemPhim(veXemPhim);
                int IDVe = db.getIDNewVeXemPhim();
                for(Integer a : listIDGhe){
                    CT_VeXemPhim ctVeXemPhim = new CT_VeXemPhim(IDVe, a);
                    db.addGhe_VeXemPhim(ctVeXemPhim);
                    db.updateGhe_XuatChieu(a, "Booked");
                }
                Intent a = new Intent(Payment_CTMActivity.this, HomeCustomerActivity.class);
                a.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(a);
                Toast.makeText(Payment_CTMActivity.this, "Đặt vé thành công", Toast.LENGTH_SHORT).show();
            }
        });
        btn_failed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent a = new Intent(Payment_CTMActivity.this, HomeCustomerActivity.class);
                a.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(a);
                Toast.makeText(Payment_CTMActivity.this, "Đặt vé thất bại", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void get_set_Variable() {
        SharedPreferences sharedPreferences = getSharedPreferences("BookingTicket", MODE_PRIVATE);
        SharedPreferences sharedPreferences2 = getSharedPreferences("Customer", MODE_PRIVATE);
        IDTaiKhoan = sharedPreferences2.getInt("IDCus", 0);
        listGhe = sharedPreferences.getString("ListIDGhe", "");
        TongTien = sharedPreferences.getInt("TongTien", 0);
        String[] listIDGheString = listGhe.split("/");
        for(String i : listIDGheString){
            if(!i.equals("")){
                listIDGhe.add(Integer.parseInt(i));
            }
        }
    }

}