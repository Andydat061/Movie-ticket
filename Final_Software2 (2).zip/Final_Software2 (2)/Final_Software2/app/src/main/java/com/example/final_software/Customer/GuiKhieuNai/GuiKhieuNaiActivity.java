package com.example.final_software.Customer.GuiKhieuNai;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.final_software.DBHelper;
import com.example.final_software.Models.KhieuNai;

import com.example.final_software.Models.PhimChieu;
import com.example.final_software.Models.XuatChieu;
import com.example.final_software.R;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Locale;

public class GuiKhieuNaiActivity extends AppCompatActivity {



    private static final int PICK_IMAGE_REQUEST = 1;
    private Uri imageUri;
    private EditText editTextComplaintDescription;
    private Spinner spinnerComplaintType;
    private ImageView imageViewComplaint;
    private Button buttonUploadImage, buttonSubmitComplaint;
    private DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gui_khieu_nai);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Khiếu nại");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        editTextComplaintDescription = findViewById(R.id.editTextComplaintDescription);
        spinnerComplaintType = findViewById(R.id.spinnerComplaintType);
        imageViewComplaint = findViewById(R.id.imageViewComplaint);
        buttonUploadImage = findViewById(R.id.buttonUploadImage);
        buttonSubmitComplaint = findViewById(R.id.buttonSubmitComplaint);

        dbHelper = new DBHelper(this);


        ArrayList<String> complaintTypes = new ArrayList<>(Arrays.asList("Âm thanh", "Hình ảnh", "Vệ sinh", "Khác"));
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, complaintTypes);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerComplaintType.setAdapter(adapter);

        buttonUploadImage.setOnClickListener(view -> openImageChooser());

        buttonSubmitComplaint.setOnClickListener(view -> submitComplaint());


    }

    private void openImageChooser() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            imageUri = data.getData();
            try {
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), imageUri);
                imageViewComplaint.setImageBitmap(bitmap);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private void submitComplaint() {
        // Gather data from the form

        String dateTime = LocalDateTime.now().getDayOfMonth() + "/"+ LocalDateTime.now().getMonthValue()+"/"+ LocalDateTime.now().getYear();
        String complaintDescription = editTextComplaintDescription.getText().toString().trim();
        String complaintType = spinnerComplaintType.getSelectedItem().toString();

        // Convert imageUri to String if needed
        String imagePath = imageUri != null ? imageUri.toString() : "";
        if (complaintDescription.isEmpty()) {
            // Show error message
            Toast.makeText(this, "Mô tả khiếu nại không được để trống", Toast.LENGTH_SHORT).show();
            return; // Exit the method
        }
        // Định dạng ngày giờ



        byte[] imageData = convertImageToByteArray(Uri.parse(imagePath));
// Tạo đối tượng KhieuNai
        KhieuNai khieuNai = new KhieuNai(
                0, // MaKhieuNai will be auto-incremented
                complaintType, // DichVu
                complaintDescription, // MoTaChiTiet
                "", // GoiYKhacPhuc (if applicable)
                dateTime, // NgayKhieuNai
                "Mới", // TrangThaiKhieuNai, adjust as needed
                1, // NguoiKN, hardcoded as 1
                imageData // HinhAnh
        );

        // Add complaint to database
        long result = dbHelper.add_KhieuNai(khieuNai);

        // Handle the result
        if (result != -1) {
            // Success
            Toast.makeText(this, "Thêm khiếu nại thành công", Toast.LENGTH_SHORT).show();

//            finish(); // Close the activity or show a success message
        } else {
            // Failure
            // Show an error message
        }
    }

    private byte[] convertImageToByteArray(Uri imageUri) {
        try {
            Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), imageUri);
            ByteArrayOutputStream stream = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, stream);
            return stream.toByteArray();
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
}
