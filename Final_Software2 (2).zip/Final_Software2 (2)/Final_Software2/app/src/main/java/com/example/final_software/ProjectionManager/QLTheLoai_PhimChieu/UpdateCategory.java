package com.example.final_software.ProjectionManager.QLTheLoai_PhimChieu;

import static com.example.final_software.R.id.update_button;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.final_software.DBHelper;
import com.example.final_software.R;

public class UpdateCategory extends AppCompatActivity {

    EditText title_input2, description_input2;
    Button update_button, delete_button;

    String id, name, description;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_category);

        title_input2=findViewById(R.id.title_input2);
        description_input2=findViewById(R.id.description_input2);
        update_button =findViewById(R.id.update_button);
        delete_button=findViewById(R.id.delete_button);
        getAndSetIntentData();
        ActionBar ab = getSupportActionBar();
        if(ab != null) {
            ab.setTitle(name);
        }

        update_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DBHelper myDB = new DBHelper(UpdateCategory.this);
                myDB.updateData(id,name,description);
            }
        });
        delete_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                confirmDialog();
            }
        });

    }
    void getAndSetIntentData() {
        if (getIntent().hasExtra("idtheloai") && getIntent().hasExtra("tentheloai")
                && getIntent().hasExtra("mota")){
            //Getting Data from Intent
            id = getIntent().getStringExtra("idtheloai");
            name = getIntent().getStringExtra("tentheloai");
            description = getIntent().getStringExtra("mota");

            //Setting Intent Data
            title_input2.setText(name);
            description_input2.setText(description);
        } else {
            Toast.makeText(this, "No data.", Toast.LENGTH_SHORT).show();
        }

    }
    void confirmDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Delete" + name + "?");
        builder.setMessage("Xác nhận xóa " + name + "?");
        builder.setPositiveButton("Có", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                DBHelper myDB = new DBHelper(UpdateCategory.this);
                myDB.deleteOneRow(id);
                finish();
            }
        });
        builder.setNegativeButton("Không", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        builder.create().show();
    }
}