package com.example.final_software.Customer.BookingTicket.Adapter;

import static android.content.Context.MODE_PRIVATE;

import static androidx.core.app.ActivityCompat.recreate;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.final_software.Customer.BookingTicket.Ghe_XuatChieu_CTMActivity;
import com.example.final_software.DBHelper;
import com.example.final_software.Models.Ghe_XuatChieu;
import com.example.final_software.ProjectionManager.QLXuatChieu.ListGhe_XuatChieuAdapter;
import com.example.final_software.R;

import java.util.ArrayList;

public class Ghe_XuatChieu_CTM_Adapter extends RecyclerView.Adapter<Ghe_XuatChieu_CTM_Adapter.MyViewHolder>{
    Context context;
    ArrayList<Ghe_XuatChieu> listGhe_XuatChieu;
    DBHelper db;
    ArrayList<Integer> list_idGhe = new ArrayList<>();
    ArrayList<String> list_maGhe = new ArrayList<>();
    int GiaVe;
    int Count = 0;
    int TongTien = 0;
    Activity a;
    private final OnSeatClickListener onSeatClickListener;
    public Ghe_XuatChieu_CTM_Adapter(Context context, ArrayList<Ghe_XuatChieu> listGhe_XuatChieu, int GiaVe, OnSeatClickListener a) {
        this.context = context;
        this.listGhe_XuatChieu = listGhe_XuatChieu;
        this.GiaVe = GiaVe;
        onSeatClickListener = a;
    }

    @NonNull
    @Override
    public Ghe_XuatChieu_CTM_Adapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_ghe_xuatchieu, parent, false);
        return new Ghe_XuatChieu_CTM_Adapter.MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Ghe_XuatChieu_CTM_Adapter.MyViewHolder holder, int position) {
        if(listGhe_XuatChieu.get(position).TrangThaiGhe.equals("Booked")){
            holder.imageGhe.setImageResource(R.drawable.ic_ghe_booked);
        }
        else {
            SharedPreferences sharedPreferences = context.getSharedPreferences("BookingTicket", MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.remove("ListGheNgoi");
            editor.remove("ListIDGhe");
            editor.remove("TongTien");
            holder.main_layout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (!holder.isChoosed && Count < 5) {
                        holder.isChoosed = true;
                        Cursor cursor = db.getReadableDatabase().rawQuery("SELECT MaGhe, LoaiGhe from Ghe where IDGhe = " + listGhe_XuatChieu.get(position).GheID, null);
                        cursor.moveToNext();
                        holder.MaGhe = cursor.getString(0);
                        holder.LoaiGhe = cursor.getString(1);
                        list_maGhe.add(holder.MaGhe);
                        list_idGhe.add(listGhe_XuatChieu.get(position).IDGhe_XuatChieu);
                        String dsGhe = "";
                        for (String i : list_maGhe) {
                            dsGhe += i + ", ";
                        }
                        editor.putString("ListGheNgoi",dsGhe);
                        String dsMaGhe = "";
                        for (Integer i : list_idGhe) {
                            dsMaGhe += i + "/";
                        }
                        editor.putString("ListIDGhe", dsMaGhe);
                        if (holder.LoaiGhe.equals("Vip")) {
                            TongTien += GiaVe * 1.05;
                        } else {
                            TongTien += GiaVe;
                        }
                        editor.putInt("TongTien",TongTien);
                        editor.apply();
                        holder.imageGhe.setImageResource(R.drawable.ic_ghe_ischoosed);
                        Count++;
                        onSeatClickListener.onSeatClick();
                    } else if (holder.isChoosed) {
                        holder.isChoosed = false;
                        list_maGhe.removeIf(s -> s.equals(holder.MaGhe));
                        list_idGhe.removeIf(s -> s == listGhe_XuatChieu.get(position).IDGhe_XuatChieu);

                        String dsGhe = "";
                        for (String i : list_maGhe) {
                            dsGhe += i + ", ";
                        }
                        editor.putString("ListGheNgoi",dsGhe);
                        String dsMaGhe = "";
                        for (Integer i : list_idGhe) {
                            dsMaGhe += i + "/";
                        }
                        editor.putString("ListIDGhe", dsMaGhe);

                        if (holder.LoaiGhe.equals("Vip")) {
                            TongTien -= GiaVe * 1.05;
                        } else {
                            TongTien -= GiaVe;
                        }
                        editor.putInt("TongTien",TongTien);
                        editor.apply();
                        holder.imageGhe.setImageResource(R.drawable.ic_xuatchieu);
                        Count--;
                        onSeatClickListener.onSeatClick();
                    }
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return listGhe_XuatChieu == null ? 0 : listGhe_XuatChieu.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        LinearLayout main_layout;
        boolean isChoosed = false;
        String MaGhe, LoaiGhe;
        ImageView imageGhe;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            main_layout = itemView.findViewById(R.id.ghe_xuatchieu_main_layout);
            db = new DBHelper(context);
            imageGhe = itemView.findViewById(R.id.ghe_xuatchieu_image);
        }
    }
    public interface OnSeatClickListener {
        void onSeatClick();
    }
}
