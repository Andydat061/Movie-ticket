package com.example.final_software;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.final_software.AccountManager.HomeAccountManagerActivity;
import com.example.final_software.Accountant.HomeAccountantActivity;
import com.example.final_software.Customer.HomeCustomerActivity;
import com.example.final_software.CustomerServiceAgent.KhieuNaiActivity;
import com.example.final_software.ProjectionManager.HomeProjectionManagerActivity;

public class LogInActivity extends AppCompatActivity {
    TextView btn_go_register, username_log, pass_log, forgot_password;
    Button btn_login;
    DBHelper db;
    String password;
    int IDCus, ChucVu;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in);
        btn_go_register = findViewById(R.id.go_register);
        btn_login = findViewById(R.id.btn_login);
        forgot_password = findViewById(R.id.forgot_password);

        username_log = findViewById(R.id.username_log);
        pass_log = findViewById(R.id.password_log);
        db = new DBHelper(LogInActivity.this);
        btn_go_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent a = new Intent(LogInActivity.this, SignUpActivity.class);
                startActivity(a);
            }
        });
        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(checkUsername()){
                    if(pass_log.getText().toString().equals(password)){
                        SharedPreferences sharedPreferences = getSharedPreferences("Customer", MODE_PRIVATE);
                        SharedPreferences.Editor editor = sharedPreferences.edit();
                        editor.putInt("IDCus", IDCus);
                        Intent a = new Intent(LogInActivity.this, HomeCustomerActivity.class);
                        startActivity(a);
                    }
                    else{
                        Toast.makeText(LogInActivity.this, "Sai mật khẩu", Toast.LENGTH_SHORT).show();
                    }
                } else if (checkUsername_Admin()) {
                    if(pass_log.getText().toString().equals(password)){
                        SharedPreferences sharedPreferences = getSharedPreferences("Admin", MODE_PRIVATE);
                        SharedPreferences.Editor editor = sharedPreferences.edit();
                        editor.putInt("IDAdmin", IDCus);
                        if(ChucVu == 0){
                            Intent a = new Intent(LogInActivity.this, HomeAccountManagerActivity.class);
                            startActivity(a);
                        } else if (ChucVu == 1) {
                            Intent a = new Intent(LogInActivity.this, HomeProjectionManagerActivity.class);
                            startActivity(a);
                        } else if (ChucVu == 2) {
                            Intent a = new Intent(LogInActivity.this, KhieuNaiActivity.class);
                            startActivity(a);
                        }
                        else{
                            Intent a = new Intent(LogInActivity.this, HomeAccountantActivity.class);
                            startActivity(a);
                        }
                    }
                    else{
                        Toast.makeText(LogInActivity.this, "Sai mật khẩu", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
    private boolean checkUsername(){
        Cursor cursor = db.getReadableDatabase().rawQuery("select * from Taikhoan", null);
        if(cursor != null){
            while (cursor.moveToNext()){
                if(username_log.getText().toString().equals(cursor.getString(1))){
                    IDCus = cursor.getInt(0);
                    password = cursor.getString(2);
                    return true;
                }
            }
            return false;
        }
        return false;
    }
    private boolean checkUsername_Admin(){
        Cursor cursor = db.getReadableDatabase().rawQuery("select * from TaikhoanNguoiDung", null);
        if(cursor != null){
            while (cursor.moveToNext()){
                if(username_log.getText().toString().equals(cursor.getString(1))){
                    IDCus = cursor.getInt(0);
                    password = cursor.getString(2);
                    ChucVu = cursor.getInt(3);
                    return true;
                }
            }
            return false;
        }
        return false;
    }
}