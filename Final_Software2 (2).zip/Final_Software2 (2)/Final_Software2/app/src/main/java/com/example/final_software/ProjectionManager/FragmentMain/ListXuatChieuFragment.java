package com.example.final_software.ProjectionManager.FragmentMain;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import com.example.final_software.DBHelper;
import com.example.final_software.Models.XuatChieu;
import com.example.final_software.ProjectionManager.QLTheLoai_PhimChieu.PhimChieu.ListPhimChieuAdapter;
import com.example.final_software.ProjectionManager.QLXuatChieu.CreateXuatChieuActivity;
import com.example.final_software.ProjectionManager.QLXuatChieu.ListXuatChieuAdapter;
import com.example.final_software.R;

import java.util.ArrayList;
import java.util.List;


public class ListXuatChieuFragment extends Fragment {
    Button btn_goto_CreateXuatChieu;
    RecyclerView rcv;
    DBHelper db;
    ListXuatChieuAdapter adapter;
    ArrayList<XuatChieu> listXuatChieu;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        Toolbar actionBar = (Toolbar) getActivity().findViewById(R.id.materialToolbar_pm);
        actionBar.setTitle("Danh sách xuất chiếu");
        actionBar.setBackgroundColor(Color.WHITE);
        ((AppCompatActivity) getActivity()).setSupportActionBar(actionBar);
        return inflater.inflate(R.layout.fragment_list_xuat_chieu, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        db = new DBHelper(getActivity());
        rcv = view.findViewById(R.id.rcv_ListXuatChieu);
        listXuatChieu = new ArrayList<>();
        store_data();
        adapter = new ListXuatChieuAdapter(getActivity(), listXuatChieu);
        rcv.setAdapter(adapter);
        rcv.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false));
        btn_goto_CreateXuatChieu = view.findViewById(R.id.btn_goto_CreateXuatChieu);
        btn_goto_CreateXuatChieu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent a = new Intent(getActivity(), CreateXuatChieuActivity.class);
                startActivity(a);
            }
        });
    }
    @Override
    public void onResume() {
        super.onResume();
        listXuatChieu = new ArrayList<>();
        db = new DBHelper(getActivity());
        store_data();
        adapter = new ListXuatChieuAdapter(getActivity(), listXuatChieu);
        rcv.setAdapter(adapter);
        rcv.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false));
    }
    public void store_data(){
        Cursor cursor = db.get_ALL_XuatChieu();
        if(cursor == null){
            Toast.makeText(getActivity(), "No data...", Toast.LENGTH_SHORT).show();
        }
        else{
            while (cursor.moveToNext()){
                XuatChieu xuatChieu = new XuatChieu(
                        cursor.getInt(0),
                        cursor.getString(1),
                        cursor.getString(2),
                        cursor.getString(3),
                        cursor.getInt(4),
                        cursor.getInt(5),
                        cursor.getInt(6)
                        );
                listXuatChieu.add(xuatChieu);
            }
            cursor.close();
        }
    }
}