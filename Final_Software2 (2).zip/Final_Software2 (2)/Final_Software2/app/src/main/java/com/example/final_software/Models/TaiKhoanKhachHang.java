package com.example.final_software.Models;

public class TaiKhoanKhachHang {
    public  int IDTaiKhoan;
    public String TaiKhoan;
    public String MatKhau;
    public String HoTen;
    public String GioiTinh;
    public String NgaySinh;
    public String SoDienThoai;
    public String Email;
    public int DiemThe;
    public String CapBac;

    public TaiKhoanKhachHang(int IDTaiKhoan, String taiKhoan, String matKhau, String hoTen, String gioiTinh, String ngaySinh, String soDienThoai, String email, int diemThe, String capBac) {
        this.IDTaiKhoan = IDTaiKhoan;
        TaiKhoan = taiKhoan;
        MatKhau = matKhau;
        HoTen = hoTen;
        GioiTinh = gioiTinh;
        NgaySinh = ngaySinh;
        SoDienThoai = soDienThoai;
        Email = email;
        DiemThe = diemThe;
        CapBac = capBac;
    }

    public TaiKhoanKhachHang(String taiKhoan, String matKhau, String hoTen, String gioiTinh, String ngaySinh, String soDienThoai, String email, int diemThe, String capBac) {
        TaiKhoan = taiKhoan;
        MatKhau = matKhau;
        HoTen = hoTen;
        GioiTinh = gioiTinh;
        NgaySinh = ngaySinh;
        SoDienThoai = soDienThoai;
        Email = email;
        DiemThe = diemThe;
        CapBac = capBac;
    }
}
