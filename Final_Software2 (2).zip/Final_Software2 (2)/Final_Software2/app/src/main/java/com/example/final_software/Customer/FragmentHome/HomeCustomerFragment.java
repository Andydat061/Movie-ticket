package com.example.final_software.Customer.FragmentHome;

import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.LinearSnapHelper;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.final_software.Customer.BookingTicket.Adapter.AutoScrollAdapter;
import com.example.final_software.Customer.BookingTicket.Adapter.ListPhimChieuAdapter;
import com.example.final_software.DBHelper;
import com.example.final_software.Models.PhimChieu;
import com.example.final_software.R;

import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

public class HomeCustomerFragment extends Fragment {
    ArrayList<Integer> arrImage;
    ArrayList<PhimChieu> arrPhimChieu, arrPhimSapChieu;
    RecyclerView rcv_banner, rcv_phimchieu, rcv_phimsapchieu;
    DBHelper db;
    AutoScrollAdapter autoScrollAdapter;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        Toolbar actionBar = (Toolbar) getActivity().findViewById(R.id.materialToolbar_ctm);
        actionBar.setTitle("Trang chủ");
        actionBar.setBackgroundColor(Color.WHITE);
        ((AppCompatActivity) getActivity()).setSupportActionBar(actionBar);
        return inflater.inflate(R.layout.fragment_home_customer, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        arrImage = new ArrayList<>();
        arrPhimChieu = new ArrayList<>();
        arrPhimSapChieu = new ArrayList<>();
        rcv_banner = view.findViewById(R.id.banner_rcv);
        rcv_phimchieu = view.findViewById(R.id.rcv_phimchieu);
        rcv_phimsapchieu = view.findViewById(R.id.rcv_phimsapchieu);
        db = new DBHelper(getActivity());
        setBanner();
        setPhimChieu();

    }
    public void setBanner(){
        arrImage.add(R.drawable.banner1);
        arrImage.add(R.drawable.banner2);
        arrImage.add(R.drawable.banner3);
        autoScrollAdapter = new AutoScrollAdapter(getActivity(), arrImage);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false);
        rcv_banner.setLayoutManager(linearLayoutManager);
        rcv_banner.setAdapter(autoScrollAdapter);

        LinearSnapHelper linearSnapHelper = new LinearSnapHelper();
        linearSnapHelper.attachToRecyclerView(rcv_banner);

        Timer timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                if(linearLayoutManager.findLastCompletelyVisibleItemPosition() < (autoScrollAdapter.getItemCount() - 1)){
                    linearLayoutManager.smoothScrollToPosition(rcv_banner, new RecyclerView.State(),linearLayoutManager.findLastCompletelyVisibleItemPosition() + 1);
                } else if(linearLayoutManager.findLastCompletelyVisibleItemPosition() == (autoScrollAdapter.getItemCount() - 1)){
                    linearLayoutManager.smoothScrollToPosition(rcv_banner, new RecyclerView.State(),0);
                }
            }
        }, 0, 5000);
    }
    public void setPhimChieu(){
        rcv_phimchieu.setLayoutManager(new GridLayoutManager(getActivity(), 2));
        String date_now = db.getCurrentDate();
        Cursor cursor = db.getPhimChieu_Home();
        if(cursor.getCount() != 0){
            while (cursor.moveToNext()){
                if(Integer.parseInt(cursor.getString(3).split("/")[2]) > Integer.parseInt(date_now.split("/")[2])){
                    if(cursor.getBlob(2) == null){
                        PhimChieu phimChieu = new PhimChieu(cursor.getInt(0),
                                cursor.getString(1),
                                null);
                        arrPhimChieu.add(phimChieu);
                    }
                    else{
                        byte[] imagebyte = cursor.getBlob(2);
                        Bitmap bitmap = BitmapFactory.decodeByteArray(imagebyte, 0, imagebyte.length);
                        PhimChieu phimChieu = new PhimChieu(cursor.getInt(0),
                                cursor.getString(1),
                                bitmap);
                        arrPhimChieu.add(phimChieu);
                    }
                }
                else{
                    if (Integer.parseInt(cursor.getString(3).split("/")[1]) > Integer.parseInt(date_now.split("/")[1])){
                        if(cursor.getBlob(2) == null){
                            PhimChieu phimChieu = new PhimChieu(cursor.getInt(0),
                                    cursor.getString(1),
                                    null);
                            arrPhimChieu.add(phimChieu);
                        }
                        else{
                            byte[] imagebyte = cursor.getBlob(2);
                            Bitmap bitmap = BitmapFactory.decodeByteArray(imagebyte, 0, imagebyte.length);
                            PhimChieu phimChieu = new PhimChieu(cursor.getInt(0),
                                    cursor.getString(1),
                                    bitmap);
                            arrPhimChieu.add(phimChieu);
                        }
                    }
                    else if(Integer.parseInt(cursor.getString(3).split("/")[1]) == Integer.parseInt(date_now.split("/")[1])){
                        if(Integer.parseInt(cursor.getString(3).split("/")[0]) > Integer.parseInt(date_now.split("/")[0])){
                            if(cursor.getBlob(2) == null){
                                PhimChieu phimChieu = new PhimChieu(cursor.getInt(0),
                                        cursor.getString(1),
                                        null);
                                arrPhimChieu.add(phimChieu);
                            }
                            else{
                                byte[] imagebyte = cursor.getBlob(2);
                                Bitmap bitmap = BitmapFactory.decodeByteArray(imagebyte, 0, imagebyte.length);
                                PhimChieu phimChieu = new PhimChieu(cursor.getInt(0),
                                        cursor.getString(1),
                                        bitmap);
                                arrPhimChieu.add(phimChieu);
                            }
                        }
                    }
                }
            }
            cursor.close();
            ListPhimChieuAdapter adapter = new ListPhimChieuAdapter(getActivity(), arrPhimChieu);
            rcv_phimchieu.setAdapter(adapter);
        }
        else Toast.makeText(getActivity(), "No data....", Toast.LENGTH_LONG).show();
    }
    public void setPhimSapChieu(){

    }
}