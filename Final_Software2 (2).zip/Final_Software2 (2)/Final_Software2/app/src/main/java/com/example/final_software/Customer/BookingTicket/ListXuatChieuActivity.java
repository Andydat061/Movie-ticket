package com.example.final_software.Customer.BookingTicket;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.example.final_software.Customer.BookingTicket.Adapter.XuatChieuCTMAdapter;
import com.example.final_software.DBHelper;
import com.example.final_software.Models.DiaDiemChieu;
import com.example.final_software.R;

import java.util.ArrayList;

public class ListXuatChieuActivity extends AppCompatActivity {
    int IDPhim;
    TextView txt_tieude, btn_back;
    RecyclerView rcv;
    XuatChieuCTMAdapter adapter;
    ArrayList<DiaDiemChieu> listDiaDiem;
    DBHelper db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_xuat_chieu);
        txt_tieude = findViewById(R.id.tieude_listXuatChieu_ctm);
        btn_back = findViewById(R.id.ic_back_listXuatChieu_ctm);
        rcv = findViewById(R.id.rcv_ListXuatChieu_Booking);
        db = new DBHelper(ListXuatChieuActivity.this);
        listDiaDiem = new ArrayList<>();
        get_set_Intent();
        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        getListDiaDiem();
        adapter = new XuatChieuCTMAdapter(ListXuatChieuActivity.this, listDiaDiem, IDPhim);
        rcv.setLayoutManager(new LinearLayoutManager(ListXuatChieuActivity.this, LinearLayoutManager.VERTICAL, false));
        rcv.setAdapter(adapter);
    }

    private void getListDiaDiem() {
        Cursor cursor = db.getDiaDiemChieu_IDPhim(IDPhim);
        if(cursor != null){
            while (cursor.moveToNext()){
                DiaDiemChieu diaDiemChieu = new DiaDiemChieu(cursor.getInt(0),
                        cursor.getString(1),
                        cursor.getInt(2),
                        cursor.getString(3));
                listDiaDiem.add(diaDiemChieu);
            }
            cursor.close();
        }
    }

    public void get_set_Intent(){
        if(getIntent().hasExtra("idphim") && getIntent().hasExtra("tenphim")){
            txt_tieude.setText(getIntent().getStringExtra("tenphim"));
            IDPhim = getIntent().getIntExtra("idphim", 0);
        }
    }
}