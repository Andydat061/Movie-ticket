package com.example.final_software.ProjectionManager.QLXuatChieu;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.final_software.Models.Ghe_XuatChieu;
import com.example.final_software.Models.XuatChieu;
import com.example.final_software.R;

import java.util.ArrayList;

public class ListGhe_XuatChieuAdapter extends RecyclerView.Adapter<ListGhe_XuatChieuAdapter.MyViewHolder>{
    Context context;
    ArrayList<Ghe_XuatChieu> listGhe_XuatChieu;

    public ListGhe_XuatChieuAdapter(Context context, ArrayList<Ghe_XuatChieu> listGhe_XuatChieu) {
        this.context = context;
        this.listGhe_XuatChieu = listGhe_XuatChieu;
    }

    @NonNull
    @Override
    public ListGhe_XuatChieuAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_ghe_xuatchieu, parent, false);
        return new ListGhe_XuatChieuAdapter.MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ListGhe_XuatChieuAdapter.MyViewHolder holder, int position) {
        holder.main_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(context, "Bạn đang chọn ghế có mã " + listGhe_XuatChieu.get(position).IDGhe_XuatChieu, Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return listGhe_XuatChieu == null ? 0 : listGhe_XuatChieu.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        LinearLayout main_layout;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            main_layout = itemView.findViewById(R.id.ghe_xuatchieu_main_layout);
        }
    }
}
