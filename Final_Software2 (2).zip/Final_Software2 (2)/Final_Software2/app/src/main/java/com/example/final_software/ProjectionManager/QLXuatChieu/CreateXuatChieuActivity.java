package com.example.final_software.ProjectionManager.QLXuatChieu;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.final_software.DBHelper;
import com.example.final_software.Models.Ghe_XuatChieu;
import com.example.final_software.Models.XuatChieu;
import com.example.final_software.R;

import java.sql.Time;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.concurrent.TimeUnit;

public class CreateXuatChieuActivity extends AppCompatActivity {
    EditText txt_NgayChieu, txt_TGBD, txt_Giave;
    Spinner spinnerPhim, spinnerRap;
    DBHelper db;
    Button btn_add;
    ArrayList<String> listPhim, listRap;
    String selectedMovie, selectedTheater;
    int IDMovie, IDRap, TgianChieu, ID_New_XuatChieu;
    String TGKT;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_xuat_chieu);
        txt_NgayChieu = findViewById(R.id.add_xuatChieu_NgayChieu);
        txt_TGBD = findViewById(R.id.add_xuatChieu_TGBD);
        txt_Giave =findViewById(R.id.add_xuatChieu_GiaVe);
        listPhim = new ArrayList<>();
        listRap = new ArrayList<>();
        btn_add = findViewById(R.id.btn_add_XuatChieu);
        db = new DBHelper(CreateXuatChieuActivity.this);
        spinnerPhim = findViewById(R.id.spinnerMovies);
        spinnerRap = findViewById(R.id.spinnerTheaters);

        get_MovieAndTheater();

        ArrayAdapter<String> movieAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item,listPhim);
        movieAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerPhim.setAdapter(movieAdapter);

        ArrayAdapter<String> theaterAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, listRap);
        theaterAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerRap.setAdapter(theaterAdapter);

        btn_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectedMovie = (String) spinnerPhim.getSelectedItem();
                selectedTheater = (String) spinnerRap.getSelectedItem();
                get_ID_MovieAndTheater();
                if(txt_NgayChieu.getText().toString().equals("") || txt_TGBD.getText().toString().equals("")){
                    Toast.makeText(CreateXuatChieuActivity.this, "Chưa nhập đủ thông tin", Toast.LENGTH_SHORT).show();
                }
                else if(!checkNgayChieu())
                    Toast.makeText(CreateXuatChieuActivity.this, "Ngày chiếu không hợp lệ", Toast.LENGTH_SHORT).show();
                else if(!checkTGBD())
                    Toast.makeText(CreateXuatChieuActivity.this, "Thời gian bắt đầu phải lớn hơn 6:00 và nhỏ hơn 21:00", Toast.LENGTH_SHORT).show();
                else if (Integer.parseInt(txt_Giave.getText().toString()) < 0 || Integer.parseInt(txt_Giave.getText().toString()) > 300000) {
                    Toast.makeText(CreateXuatChieuActivity.this, "Giá vé phải lớn lơn 0 và bé hơn 300.000 đ", Toast.LENGTH_SHORT).show();
                } else if (checkXuatChieu()) {
                    Toast.makeText(CreateXuatChieuActivity.this, "Trùng xuất chiếu của rạp phim", Toast.LENGTH_SHORT).show();
                } else{
                    XuLyThoiGianKT();
                    XuatChieu xuatChieu = new XuatChieu(txt_NgayChieu.getText().toString(),
                            txt_TGBD.getText().toString(),
                            TGKT,
                            IDRap, IDMovie,
                            Integer.parseInt(txt_Giave.getText().toString()));
                    db.add_XuatChieu(xuatChieu);
                    get_ID_New_XuatChieu();
                    add_Ghe_XuatChieu();
                    Toast.makeText(CreateXuatChieuActivity.this, "Thêm thành công", Toast.LENGTH_SHORT).show();
                    finish();
                }
            }
        });
    }
    public void get_MovieAndTheater(){
        Cursor cursor = db.get_All_Name_Phim();
        if(cursor != null){
            while (cursor.moveToNext()){
                listPhim.add(cursor.getString(0));
            }
            cursor.close();
        }
        cursor = db.get_All_Name_Rap();
        if(cursor != null){
            while (cursor.moveToNext()){
                listRap.add(cursor.getString(0));
            }
            cursor.close();
        }
    }
    public void get_ID_MovieAndTheater(){
        Cursor cursor = db.get_ID_Phim_By_Name(selectedMovie);
        if(cursor != null){
            while (cursor.moveToNext()){
                IDMovie = cursor.getInt(0);
                TgianChieu = cursor.getInt(1);
            }
            cursor.close();
        }
        cursor = db.get_ID_Rap_By_Name(selectedTheater);
        if(cursor != null){
            while (cursor.moveToNext()){
                IDRap = cursor.getInt(0);
            }
            cursor.close();
        }
    }
    public boolean checkTGBD(){
        if(txt_TGBD.getText().toString().split(":").length == 3){
            int hours = Integer.parseInt(txt_TGBD.getText().toString().split(":")[0]);
            int minutes = Integer.parseInt(txt_TGBD.getText().toString().split(":")[1]);
            int seconds = Integer.parseInt(txt_TGBD.getText().toString().split(":")[2]);
            return hours >= 6 && hours <= 20 && minutes >= 0 && minutes <= 60 && seconds >= 0 && seconds <= 60;
        }
        else return false;
    }
    public boolean checkNgayChieu(){
        if(txt_NgayChieu.getText().toString().split("/").length == 3){
            int days = Integer.parseInt(txt_NgayChieu.getText().toString().split("/")[0]);
            int months = Integer.parseInt(txt_NgayChieu.getText().toString().split("/")[1]);
            int year = Integer.parseInt(txt_NgayChieu.getText().toString().split("/")[2]);
            if(year == LocalDateTime.now().getYear()){
                if(months == LocalDateTime.now().getMonthValue()){
                    return days > LocalDateTime.now().getDayOfMonth() && days <= 30;
                }
                else if(months > LocalDateTime.now().getMonthValue() && months <= 12){
                    return days > 0 && days <=30;
                }
                else return false;
            }
            else if(year > LocalDateTime.now().getYear() && year < 3000){
                if(months > 0 && months <= 12) return true;
                else return days > 0 && days <= 30;
            }
            else return false;
        }
        else return false;
    }
    public boolean checkXuatChieu(){
        Cursor cursor = db.get_XuatChieuTrung(txt_NgayChieu.getText().toString(),txt_TGBD.getText().toString(), IDRap);
        return cursor.getCount() != 0;
    }
    public void XuLyThoiGianKT(){
        int hours = Integer.parseInt(txt_TGBD.getText().toString().split(":")[0]);
        int minutes = Integer.parseInt(txt_TGBD.getText().toString().split(":")[1]);
        int seconds = Integer.parseInt(txt_TGBD.getText().toString().split(":")[2]);
        if(TgianChieu >= 60){
            hours += TgianChieu/ 60;
            minutes += TgianChieu % 60;
        }
        else minutes += TgianChieu;
        if(minutes < 10){
            if(seconds <10){
                TGKT = hours +":0"+minutes+":0"+seconds;
            }
            else TGKT = hours +":0"+minutes+":"+seconds;
        }
        else{
            if(seconds <10){
                TGKT = hours +":"+minutes+":0"+seconds;
            }
            else TGKT = hours +":"+minutes+":"+seconds;
        }
    }
    public void get_ID_New_XuatChieu(){
        Cursor cursor = db.get_NewXuatChieu();
        if(cursor != null){
            while (cursor.moveToNext()){
                ID_New_XuatChieu = cursor.getInt(0);
            }
            cursor.close();
        }
    }
    public void add_Ghe_XuatChieu(){
        Cursor cursor = db.get_All_Ghe_Rap(IDRap);
        if(cursor != null){
            while (cursor.moveToNext()){
                Ghe_XuatChieu gheXuatChieu = new Ghe_XuatChieu(cursor.getInt(0), ID_New_XuatChieu, "Trống");
                db.add_Ghe_XuatChieu(gheXuatChieu);
            }
            cursor.close();
        }
    }
}