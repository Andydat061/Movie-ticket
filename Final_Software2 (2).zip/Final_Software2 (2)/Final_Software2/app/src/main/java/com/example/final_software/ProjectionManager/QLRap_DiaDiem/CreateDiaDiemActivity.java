package com.example.final_software.ProjectionManager.QLRap_DiaDiem;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.final_software.DBHelper;
import com.example.final_software.Models.DiaDiemChieu;
import com.example.final_software.R;

public class CreateDiaDiemActivity extends AppCompatActivity {
    TextView getName, getNumberTheater, getDescription;
    Button btn_add;
    DBHelper db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_dia_diem);
        getName = findViewById(R.id.get_add_diadiem_Name);
        getNumberTheater = findViewById(R.id.get_add_diadiem_NumberTheater);
        getDescription = findViewById(R.id.get_add_diadiem_Description);
        btn_add = findViewById(R.id.btn_add_diadiemchieu);
        db = new DBHelper(CreateDiaDiemActivity.this);
        btn_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(getName.getText().toString().equals("") ||
                        getNumberTheater.getText().toString().equals("") ||
                        getDescription.getText().toString().equals("") ){
                    Toast.makeText(CreateDiaDiemActivity.this, "Chưa nhập đủ thông tin", Toast.LENGTH_SHORT).show();
                }
                else if(getName.getText().toString().length() > 30){
                    Toast.makeText(CreateDiaDiemActivity.this, "Tên địa điểm giới hạn 30 ký tự", Toast.LENGTH_SHORT).show();
                }
                else if(Integer.parseInt(getNumberTheater.getText().toString()) <= 0 || Integer.parseInt(getNumberTheater.getText().toString()) > 10){
                    Toast.makeText(CreateDiaDiemActivity.this, "Số lượng rạp của một địa điểm nhỏ hơn 10 rạp", Toast.LENGTH_SHORT).show();
                } else if (getDescription.getText().toString().length() > 300) {
                    Toast.makeText(CreateDiaDiemActivity.this, "Mô tả địa điểm giới hạn 300 ký tự", Toast.LENGTH_SHORT).show();
                }
                else {
                    DiaDiemChieu diaDiemChieu = new DiaDiemChieu(getName.getText().toString(),
                            Integer.parseInt(getNumberTheater.getText().toString()),
                            getDescription.getText().toString());
                    db.addDiaDiemChieu(diaDiemChieu);
                    Toast.makeText(CreateDiaDiemActivity.this, "Thêm địa điểm thành công", Toast.LENGTH_SHORT).show();
                    finish();
                }
            }
        });

    }
}