package com.example.final_software.Models;

public class Ghe {
    public int IDGhe;
    public String MaGhe;
    public String LoaiGhe;
    public int RapID;

    public Ghe(int IDGhe, String maGhe, String loaiGhe, int rapID) {
        this.IDGhe = IDGhe;
        MaGhe = maGhe;
        LoaiGhe = loaiGhe;
        RapID = rapID;
    }

    public Ghe(String maGhe, String loaiGhe, int rapID) {
        MaGhe = maGhe;
        LoaiGhe = loaiGhe;
        RapID = rapID;
    }
}
