package com.example.final_software.ProjectionManager.QLTheLoai_PhimChieu.PhimChieu;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.final_software.DBHelper;
import com.example.final_software.Models.Movie;
import com.example.final_software.R;

import java.time.LocalDateTime;

public class CreateMovieActivity extends AppCompatActivity {
    EditText getName, getDate,getTime, getDirector, getActor, getLanguage;
    Button btn_add;
    ImageView get_image;
    DBHelper db;
    private static final int PICK_IMAGE_REQUEST = 99;
    private Uri imagePath;
    private Bitmap imageToStore;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_movie);
        getName = findViewById(R.id.get_add_movie_name);
        getDate = findViewById(R.id.get_add_movie_date);
        getTime = findViewById(R.id.get_add_movie_time);
        getDirector = findViewById(R.id.get_add_movie_director);
        getActor = findViewById(R.id.get_add_movie_actor);
        getLanguage = findViewById(R.id.get_add_movie_language);
        btn_add = findViewById(R.id.btn_add_movie);
        db = new DBHelper(CreateMovieActivity.this);
        get_image = findViewById(R.id.get_add_movie_image);
        get_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                chooseImage();
            }
        });
        btn_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checkEmpty()){
                    if (checkFormat()){
                        if(checkNameMovie()){
                            Movie newMovie = new Movie(getName.getText().toString(),
                                    getDate.getText().toString(),
                                    Integer.parseInt(getTime.getText().toString()),
                                    getDirector.getText().toString(),
                                    getActor.getText().toString(),
                                    getDirector.getText().toString(),
                                    imageToStore);
                            db.createMovie(newMovie);
                            finish();
                        }
                    }
                }
            }
        });
    }
    public boolean checkEmpty(){
        if(imageToStore == null){
            Toast.makeText(this, "Vui lòng thêm hình ảnh", Toast.LENGTH_SHORT).show();
            return false;
        }
        if(!getName.getText().toString().equals("") && !getDate.getText().toString().equals("")
                && !getDirector.getText().toString().equals("") && !getActor.getText().toString().equals("")
                && !getLanguage.getText().toString().equals("")&& !getTime.getText().toString().equals("")){
            return true;
        }
        else {
            Toast.makeText(this, "Vui lòng nhập đủ thông tin", Toast.LENGTH_SHORT).show();
            return false;
        }
    }
    public boolean checkFormat(){
        if(getName.getText().toString().trim().length()>= 30){
            Toast.makeText(this, "Tên phim chiếu nhỏ hơn 30 ký tự", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (!checkNgayChieu()){
            return false;
        }
        if(Integer.valueOf(getTime.getText().toString().trim()) < 90 ||Integer.valueOf(getTime.getText().toString().trim()) > 180){
            Toast.makeText(this, "Thời lượng phim phải lớn hơn 90 phút và nhỏ hơn 180 phút", Toast.LENGTH_SHORT).show();
            return false;
        }
        if(getDirector.getText().toString().trim().length()>= 50){
            Toast.makeText(this, "Tên đạo diễn giới hạn 50 ký tự", Toast.LENGTH_SHORT).show();
            return false;
        }
        if(getActor.getText().toString().trim().length()>= 50){
            Toast.makeText(this, "Tên diễn viên giới hạn 50 ký tự", Toast.LENGTH_SHORT).show();
            return false;
        }
        if(getLanguage.getText().toString().trim().length()>= 20){
            Toast.makeText(this, "Ngôn ngữ chiếu giới hạn 30 ký tự", Toast.LENGTH_SHORT).show();
            return false;
        }
        else return true;
    }
    public boolean checkNgayChieu(){
        if(getDate.getText().toString().split("/").length == 3){
            int days = Integer.parseInt(getDate.getText().toString().split("/")[0]);
            int months = Integer.parseInt(getDate.getText().toString().split("/")[1]);
            int year = Integer.parseInt(getDate.getText().toString().split("/")[2]);
            if(year == LocalDateTime.now().getYear()){
                if(months == LocalDateTime.now().getMonthValue()){
                    return days > LocalDateTime.now().getDayOfMonth() && days <= 30;
                }
                else if(months > LocalDateTime.now().getMonthValue() && months <= 12){
                    return days > 0 && days <=30;
                }
                else return false;
            }
            else if(year > LocalDateTime.now().getYear() && year < 3000){
                if(months > 0 && months <= 12) return true;
                else return days > 0 && days <= 30;
            }
            else return false;
        }
        else return false;
    }
    public boolean checkNameMovie() {
        Cursor cursor = db.getMovie_byName(getName.getText().toString().trim());
        while (cursor.moveToNext()) {
            if (getName.getText().toString().trim().equals(cursor.getString(1))) {
                Toast.makeText(CreateMovieActivity.this, "Phim chiếu đã tồn tại", Toast.LENGTH_SHORT).show();
                return false;
            } else {
                return true;
            }
        }
        return true;
    }
    private void chooseImage() {
        try {
            Intent a = new Intent();
            a.setType("image/*");
            a.setAction(Intent.ACTION_GET_CONTENT);
            startActivityForResult(a, PICK_IMAGE_REQUEST);
        }
        catch (Exception e){
            Toast.makeText(this, "Thêm ảnh thất bại" + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        try{
            super.onActivityResult(requestCode, resultCode, data);
            if(requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null){
                imagePath = data.getData();
                imageToStore = MediaStore.Images.Media.getBitmap(getContentResolver(), imagePath);
                get_image.setImageBitmap(imageToStore);
            }
        }
        catch (Exception e){
            Toast.makeText(this, " "+ e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

}