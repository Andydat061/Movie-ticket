package com.example.final_software.Models;

public class TaiKhoanNguoiDung {
    public  int MaTaiKhoanND;
    public  String TenDangNhap;
    public String MatKhau;
    public int ChucVu;

    public TaiKhoanNguoiDung(int maTaiKhoanND, String tenDangNhap, String matKhau, int chucVu) {
        MaTaiKhoanND = maTaiKhoanND;
        TenDangNhap = tenDangNhap;
        MatKhau = matKhau;
        ChucVu = chucVu;
    }

    public TaiKhoanNguoiDung(String tenDangNhap, String matKhau, int chucVu) {
        TenDangNhap = tenDangNhap;
        MatKhau = matKhau;
        ChucVu = chucVu;
    }
}
