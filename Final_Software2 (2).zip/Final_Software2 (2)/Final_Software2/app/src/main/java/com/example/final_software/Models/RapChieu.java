package com.example.final_software.Models;

public class RapChieu {
    public int IDRap;
    public String TenRap;
    public int SoTTRap;
    public int DiaDiemRap;
    public int SoLuongGhe;
    public int SoLuongGheVip;

    public RapChieu(int IDRap, String tenRap, int soTTRap, int diaDiemRap, int soLuongGhe, int soLuongGheVip) {
        this.IDRap = IDRap;
        TenRap = tenRap;
        SoTTRap = soTTRap;
        DiaDiemRap = diaDiemRap;
        SoLuongGhe = soLuongGhe;
        SoLuongGheVip = soLuongGheVip;
    }

    public RapChieu(String tenRap, int soTTRap, int diaDiemRap, int soLuongGhe, int soLuongGheVip) {
        TenRap = tenRap;
        SoTTRap = soTTRap;
        DiaDiemRap = diaDiemRap;
        SoLuongGhe = soLuongGhe;
        SoLuongGheVip = soLuongGheVip;
    }
}
