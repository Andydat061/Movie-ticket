package com.example.final_software.Models;

public class DiaDiemChieu {
    public int IDDiaDiem;
    public String TenDiaDiem;
    public int SoLuongRap;
    public String MoTa;

    public DiaDiemChieu(int IDDiaDiem, String tenDiaDiem, int soLuongRap, String moTa) {
        this.IDDiaDiem = IDDiaDiem;
        TenDiaDiem = tenDiaDiem;
        SoLuongRap = soLuongRap;
        MoTa = moTa;
    }

    public DiaDiemChieu(String tenDiaDiem, int soLuongRap, String moTa) {
        TenDiaDiem = tenDiaDiem;
        SoLuongRap = soLuongRap;
        MoTa = moTa;
    }

    public DiaDiemChieu(int IDDiaDiem, String tenDiaDiem) {
        this.IDDiaDiem = IDDiaDiem;
        TenDiaDiem = tenDiaDiem;
    }
}
