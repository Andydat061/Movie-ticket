package com.example.final_software.Models;

import android.net.Uri;

public class KhieuNai {
    private int maKhieuNai;
    private String dichVu;
    private String moTaChiTiet;
    private String goiYKhacPhuc;
    private String ngayKhieuNai;
    private String trangThaiKhieuNai;
    private int nguoiKN;
    private byte[] hinhAnh; // URL hoặc đường dẫn hình ảnh

    // Default constructor
    public KhieuNai() {
    }

    // Parameterized constructor
    public KhieuNai(int maKhieuNai, String dichVu, String moTaChiTiet, String goiYKhacPhuc,
                    String ngayKhieuNai, String trangThaiKhieuNai, int nguoiKN,
                    byte[] hinhAnh) {
        this.maKhieuNai = maKhieuNai;
        this.dichVu = dichVu;
        this.moTaChiTiet = moTaChiTiet;
        this.goiYKhacPhuc = goiYKhacPhuc;
        this.ngayKhieuNai = ngayKhieuNai;
        this.trangThaiKhieuNai = trangThaiKhieuNai;
        this.nguoiKN = nguoiKN;
        this.hinhAnh = hinhAnh;
    }

    // Getters and Setters
    public int getMaKhieuNai() {
        return maKhieuNai;
    }

    public void setMaKhieuNai(int maKhieuNai) {
        this.maKhieuNai = maKhieuNai;
    }

    public String getDichVu() {
        return dichVu;
    }

    public void setDichVu(String dichVu) {
        this.dichVu = dichVu;
    }

    public String getMoTaChiTiet() {
        return moTaChiTiet;
    }

    public void setMoTaChiTiet(String moTaChiTiet) {
        this.moTaChiTiet = moTaChiTiet;
    }

    public String getGoiYKhacPhuc() {
        return goiYKhacPhuc;
    }

    public void setGoiYKhacPhuc(String goiYKhacPhuc) {
        this.goiYKhacPhuc = goiYKhacPhuc;
    }

    public String getNgayKhieuNai() {
        return ngayKhieuNai;
    }

    public void setNgayKhieuNai(String ngayKhieuNai) {
        this.ngayKhieuNai = ngayKhieuNai;
    }

    public String getTrangThaiKhieuNai() {
        return trangThaiKhieuNai;
    }

    public void setTrangThaiKhieuNai(String trangThaiKhieuNai) {
        this.trangThaiKhieuNai = trangThaiKhieuNai;
    }

    public int getNguoiKN() {
        return nguoiKN;
    }

    public void setNguoiKN(int nguoiKN) {
        this.nguoiKN = nguoiKN;
    }


    public byte[] getHinhAnh() {
        return hinhAnh;
    }

    public void setHinhAnh(byte[] hinhAnh) {
        this.hinhAnh = hinhAnh;
    }


    @Override
    public String toString() {
        return "KhieuNai{" +
                "maKhieuNai=" + maKhieuNai +
                ", dichVu='" + dichVu + '\'' +
                ", moTaChiTiet='" + moTaChiTiet + '\'' +
                ", goiYKhacPhuc='" + goiYKhacPhuc + '\'' +
                ", ngayKhieuNai='" + ngayKhieuNai + '\'' +
                ", trangThaiKhieuNai='" + trangThaiKhieuNai + '\'' +
                ", nguoiKN=" + nguoiKN +
                ", hinhAnh='" + hinhAnh + '\'' +
                '}';
    }
}
