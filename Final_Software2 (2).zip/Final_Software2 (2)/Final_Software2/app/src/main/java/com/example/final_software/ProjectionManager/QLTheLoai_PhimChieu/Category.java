package com.example.final_software.ProjectionManager.QLTheLoai_PhimChieu;

import static com.example.final_software.R.id.add_button;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.final_software.DBHelper;
import com.example.final_software.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class Category extends AppCompatActivity {
    RecyclerView recyclerView;
    FloatingActionButton add_button;

    DBHelper myDB;
    ArrayList<String> theloai_id, theloai_ten, theloai_mota;
    CategoryAdapter categoryAdapter;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_category);

        recyclerView = findViewById(R.id.recyclerView);
        add_button = findViewById(R.id.add_button);
        add_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Category.this, AddCategory.class);
                startActivity(intent);
            }
        });

        myDB = new DBHelper(Category.this);
        theloai_id=new ArrayList<>();
        theloai_ten=new ArrayList<>();
        theloai_mota=new ArrayList<>();
        storeDataInArray();
        categoryAdapter = new CategoryAdapter(Category.this, this,theloai_id, theloai_ten, theloai_mota);
        recyclerView.setAdapter(categoryAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(Category.this));
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1) {
            recreate();
        }
    }

    public void storeDataInArray() {
        Cursor cursor = myDB.readAllData();
        if (cursor.getCount() == 0) {
            Toast.makeText(this, "Không có dữ liệu.", Toast.LENGTH_SHORT).show();
        } else {
            while (cursor.moveToNext()) {
                theloai_id.add(cursor.getString(0));
                theloai_ten.add(cursor.getString(1));
                theloai_mota.add(cursor.getString(2));
            }
        }
    }
}
