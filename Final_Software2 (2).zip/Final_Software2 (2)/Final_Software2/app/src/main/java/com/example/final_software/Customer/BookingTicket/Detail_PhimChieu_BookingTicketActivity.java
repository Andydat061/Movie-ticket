package com.example.final_software.Customer.BookingTicket;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.final_software.DBHelper;
import com.example.final_software.R;

public class Detail_PhimChieu_BookingTicketActivity extends AppCompatActivity {
    TextView txt_tenphim, txt_ngayphathanh, txt_giochieu, txt_daodien, txt_dienvien, txt_ngonngu, btn_back;
    ImageView anhQC;
    int IDPhim;
    DBHelper db;
    byte[] imagebyte;
    Button btn_goto_chooseXuatChieu;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_phim_chieu_booking_ticket);
        txt_tenphim = findViewById(R.id.detail_phimchieu_ctm_tenphim);
        txt_ngayphathanh = findViewById(R.id.detail_phimchieu_ctm_ngayphathanh);
        txt_giochieu = findViewById(R.id.detail_phimchieu_ctm_giochieu);
        txt_daodien = findViewById(R.id.detail_phimchieu_ctm_daodien);
        txt_dienvien = findViewById(R.id.detail_phimchieu_ctm_dienvien);
        txt_ngonngu = findViewById(R.id.detail_phimchieu_ctm_ngonngu);
        anhQC = findViewById(R.id.detail_phimchieu_ctm_anhqc);
        btn_back = findViewById(R.id.ic_back_detail_phimchieu_ctm);
        btn_goto_chooseXuatChieu = findViewById(R.id.goto_chooseXuatChieu);
        db = new DBHelper(Detail_PhimChieu_BookingTicketActivity.this);
        get_setIntent();
        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        btn_goto_chooseXuatChieu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent a = new Intent(Detail_PhimChieu_BookingTicketActivity.this, ListXuatChieuActivity.class);
                a.putExtra("idphim", IDPhim);
                a.putExtra("tenphim", getIntent().getStringExtra("tenphim"));
                startActivity(a);
            }
        });
    }
    public void get_setIntent(){
        IDPhim = getIntent().getIntExtra("idphim", 0);
        txt_tenphim.setText(getIntent().getStringExtra("tenphim"));
        Cursor cursor = db.getReadableDatabase().rawQuery("Select * from PhimChieu where IDPhim = "+ IDPhim, null);
        if(cursor != null){
            while (cursor.moveToNext()){
                txt_ngayphathanh.setText("Ngày phát hành: " + cursor.getString(4));
                txt_giochieu.setText("Thời gian chiếu: " + cursor.getString(5));
                txt_daodien.setText("Đạo diễn: " + cursor.getString(6));
                txt_dienvien.setText("Diễn viên: " + cursor.getString(7));
                txt_ngonngu.setText("Ngôn ngữ: " + cursor.getString(8));
            }
            cursor.close();
        }
        if(getIntent().hasExtra("anhqc")){
            imagebyte = getIntent().getByteArrayExtra("anhqc");
            Bitmap bitmap = BitmapFactory.decodeByteArray(imagebyte, 0, imagebyte.length);
            anhQC.setImageBitmap(bitmap);
        }
        else{
            anhQC.setImageResource(R.drawable.tt_conan);
        }
    }
}