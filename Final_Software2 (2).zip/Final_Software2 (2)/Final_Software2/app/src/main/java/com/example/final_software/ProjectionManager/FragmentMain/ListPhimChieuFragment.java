package com.example.final_software.ProjectionManager.FragmentMain;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import com.example.final_software.DBHelper;
import com.example.final_software.Models.Movie;
import com.example.final_software.ProjectionManager.QLTheLoai_PhimChieu.PhimChieu.CreateMovieActivity;
import com.example.final_software.ProjectionManager.QLTheLoai_PhimChieu.PhimChieu.ListPhimChieuAdapter;
import com.example.final_software.R;

import java.util.ArrayList;


public class ListPhimChieuFragment extends Fragment {
    Button gotoAdd;
    DBHelper db;
    RecyclerView recyclerView;
    ArrayList<Movie> arrMovie;
    ListPhimChieuAdapter listPhimChieuAdapter;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        Toolbar actionBar = (Toolbar) getActivity().findViewById(R.id.materialToolbar_pm);
        actionBar.setTitle("Danh sách phim chiếu");
        actionBar.setBackgroundColor(Color.WHITE);
        ((AppCompatActivity) getActivity()).setSupportActionBar(actionBar);
        return inflater.inflate(R.layout.fragment_list_phim_chieu, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        recyclerView = view.findViewById(R.id.rcv_pjm_movie);
        arrMovie = new ArrayList<>();
        db = new DBHelper(getActivity());
        gotoAdd = view.findViewById(R.id.btn_goto_addMovie);
        store_data_to_list();
        listPhimChieuAdapter = new ListPhimChieuAdapter(getActivity(), arrMovie);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false));
        recyclerView.setAdapter(listPhimChieuAdapter);
        gotoAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent a = new Intent(getActivity(), CreateMovieActivity.class);
                startActivity(a);
            }
        });
    }
    @Override
    public void onResume() {
        super.onResume();
        arrMovie = new ArrayList<>();
        db = new DBHelper(getActivity());
        store_data_to_list();
        listPhimChieuAdapter = new ListPhimChieuAdapter(getActivity(), arrMovie);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false));
        recyclerView.setAdapter(listPhimChieuAdapter);
    }
    void store_data_to_list(){
        Cursor cursor = db.getMovie();
        if(cursor == null)
            Toast.makeText(getActivity(), "No data.", Toast.LENGTH_SHORT).show();
        else{
            while(cursor.moveToNext()){
                byte[] imagebyte = cursor.getBlob(2);
                Bitmap bitmap = BitmapFactory.decodeByteArray(imagebyte, 0, imagebyte.length);
                Movie bookModel = new Movie(cursor.getInt(0),
                        cursor.getString(1),
                        cursor.getString(4),
                        cursor.getInt(5),
                        cursor.getString(6),
                        cursor.getString(7),
                        cursor.getString(8),
                        bitmap);
                arrMovie.add(bookModel);
            }
            cursor.close();
        }
    }
}