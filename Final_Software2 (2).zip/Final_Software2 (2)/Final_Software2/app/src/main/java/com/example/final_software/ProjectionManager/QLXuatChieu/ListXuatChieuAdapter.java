package com.example.final_software.ProjectionManager.QLXuatChieu;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.final_software.DBHelper;
import com.example.final_software.Models.XuatChieu;
import com.example.final_software.R;

import java.util.ArrayList;
import java.util.List;

public class ListXuatChieuAdapter extends RecyclerView.Adapter<ListXuatChieuAdapter.MyViewHolder>{
    Context context;
    ArrayList<XuatChieu> listXuatChieu;
    public ListXuatChieuAdapter(Context context, ArrayList<XuatChieu> listXuatChieu) {
        this.context = context;
        this.listXuatChieu = listXuatChieu;
    }

    @NonNull
    @Override
    public ListXuatChieuAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_xuatchieu, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ListXuatChieuAdapter.MyViewHolder holder, int position) {
        holder.get_ID.setText(listXuatChieu.get(position).IDXuatChieu + "");
        holder.get_NgayChieu.setText("Ngày chiếu: " + listXuatChieu.get(position).NgayChieu);
        holder.get_TgianBD.setText("Thời gian bắt đầu: " + listXuatChieu.get(position).ThoiGianBatDau + "");
        holder.get_TGKT.setText("Thời gian kết thúc: " + listXuatChieu.get(position).ThoiGianKetThuc + "");
        holder.get_RapChieu.setText("Rạp chiếu: " + listXuatChieu.get(position).RapChieu + "");
        holder.get_PhimChieu.setText("Phim chiếu: " + listXuatChieu.get(position).PhimChieu + "");
        holder.get_GiaVe.setText("Giá vé: " + listXuatChieu.get(position).GiaVe);
        holder.mainChapterLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent a = new Intent(holder.itemView.getContext(), DetailXuatChieuActivity.class);
                a.putExtra("idxuatchieu", listXuatChieu.get(position).IDXuatChieu);
                a.putExtra("ngaychieu", listXuatChieu.get(position).NgayChieu);
                a.putExtra("tgbd", listXuatChieu.get(position).ThoiGianBatDau);
                a.putExtra("tgkt", listXuatChieu.get(position).ThoiGianKetThuc);
                a.putExtra("rapchieu", listXuatChieu.get(position).RapChieu);
                a.putExtra("phimchieu", listXuatChieu.get(position).PhimChieu);
                a.putExtra("giave", listXuatChieu.get(position).GiaVe);
                holder.itemView.getContext().startActivity(a);
            }
        });
    }

    @Override
    public int getItemCount() {
        return listXuatChieu == null ? 0 : listXuatChieu.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView get_ID, get_NgayChieu, get_TgianBD, get_TGKT, get_PhimChieu, get_RapChieu, get_GiaVe;
        LinearLayout mainChapterLayout;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            get_ID = itemView.findViewById(R.id.item_xuatchieu_ID);
            get_NgayChieu = itemView.findViewById(R.id.item_xuatchieu_NgayChieu);
            get_TgianBD = itemView.findViewById(R.id.item_xuatchieu_TgianBD);
            get_TGKT = itemView.findViewById(R.id.item_xuatchieu_TgianKT);
            get_PhimChieu = itemView.findViewById(R.id.item_xuatchieu_PhimChieu);
            get_RapChieu = itemView.findViewById(R.id.item_xuatchieu_RapChieu);
            get_GiaVe = itemView.findViewById(R.id.item_xuatchieu_GiaVe);
            mainChapterLayout = itemView.findViewById(R.id.item_xuatchieu_mainLayout);
        }
    }
}
