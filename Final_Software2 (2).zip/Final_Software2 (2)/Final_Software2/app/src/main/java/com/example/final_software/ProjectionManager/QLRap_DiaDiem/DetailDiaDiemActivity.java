package com.example.final_software.ProjectionManager.QLRap_DiaDiem;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import com.example.final_software.DBHelper;
import com.example.final_software.R;

public class DetailDiaDiemActivity extends AppCompatActivity {
    TextView getID, getName, getNumberTT, getDes;
    Button btn_delete, btn_gotoUpdate, btn_gotoRapChieu;
    int IDDiaDiem;
    DBHelper db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_dia_diem);
        getID = findViewById(R.id.detail_diadiemchieu_id);
        getName = findViewById(R.id.detail_diadiemchieu_Name);
        getNumberTT = findViewById(R.id.detail_diadiemchieu_NumberTheater);
        getDes = findViewById(R.id.detail_diadiemchieu_Description);
        btn_delete = findViewById(R.id.btn_delete_diadiem);
        btn_gotoUpdate  = findViewById(R.id.btn_gotoUpdate_diadiem);
        btn_gotoRapChieu  = findViewById(R.id.btn_gotoListRapChieu);
        db = new DBHelper(DetailDiaDiemActivity.this);
        get_setIntent();
    }
    public void get_setIntent(){
        if(getIntent().hasExtra("iddiadiem")){
            IDDiaDiem = getIntent().getIntExtra("iddiadiem", 0);
            Cursor cursor = db.getReadableDatabase().rawQuery("SELECT * FROM DIADIEMCHIEU WHERE IDDiaDiem = " + IDDiaDiem, null);
            cursor.moveToNext();
            if(cursor != null){
                getID.setText("ID: "+ IDDiaDiem);
                getName.setText("Tên địa điểm: "+ cursor.getString(1));
                getNumberTT.setText("Số lượng rạp: "+ cursor.getString(2));
                getDes.setText(""+ cursor.getString(3));
            }
        }
    }
}