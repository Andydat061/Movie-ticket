package com.example.final_software.CustomerServiceAgent;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.example.final_software.DBHelper;
import com.example.final_software.Models.PhanHoiKhieuNai;
import com.example.final_software.R;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class GuiPhanHoiActivity extends AppCompatActivity {

    TextView textViewMaKhieuNai, textViewTieuDe, textViewMoTaChiTiet;
    EditText editTextPhanHoiKhieuNai;
    Button buttonPhanHoiKhieuNai;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_gui_phan_hoi);

        int maKhieuNai = getIntent().getIntExtra("MA_KHIEU_NAI", -1);
        String tieuDe = getIntent().getStringExtra("TIEU_DE");
        String chiTiet = getIntent().getStringExtra("CHI_TIET");

        textViewMaKhieuNai = findViewById(R.id.textViewMaKhieuNai);
        textViewTieuDe = findViewById(R.id.textViewTieuDe);
        textViewMoTaChiTiet = findViewById(R.id.textViewMoTaChiTiet);
        editTextPhanHoiKhieuNai = findViewById(R.id.editTextPhanHoiKhieuNai);
        buttonPhanHoiKhieuNai = findViewById(R.id.buttonPhanHoiKhieuNai);

        textViewMaKhieuNai.setText(String.valueOf(maKhieuNai));
        textViewTieuDe.setText(tieuDe);
        textViewMoTaChiTiet.setText(chiTiet);

        // GuiPhanHoiActivity.java

        buttonPhanHoiKhieuNai.setOnClickListener(view -> {
            String phanHoiCuThe = editTextPhanHoiKhieuNai.getText().toString().trim();

            if (phanHoiCuThe.isEmpty()) {
                Toast.makeText(this, "Vui lòng nhập phản hồi chi tiết", Toast.LENGTH_SHORT).show();
                return;
            }

            String ngayPhanHoi = getCurrentDateTime();
            int nguoiPH = 3;

            PhanHoiKhieuNai phanHoiKhieuNai = new PhanHoiKhieuNai(0, tieuDe, "Dịch vụ", phanHoiCuThe, ngayPhanHoi, maKhieuNai, nguoiPH);

            DBHelper dbHelper = new DBHelper(this);
            long result = dbHelper.addPhanHoiKhieuNai(phanHoiKhieuNai);


            if (result != -1) {
                Toast.makeText(this, "Phản hồi khiếu nại đã được gửi thành công", Toast.LENGTH_SHORT).show();

                // Trả kết quả thành công về cho ChiTietKhieuNaiActivity
                Intent resultIntent = new Intent();
                resultIntent.putExtra("UPDATE_STATUS", true);
                setResult(RESULT_OK, resultIntent);
                finish();
            } else {
                Toast.makeText(this, "Đã có lỗi xảy ra, vui lòng thử lại", Toast.LENGTH_SHORT).show();
            }
        });


    }

    public String getCurrentDateTime() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        return dateFormat.format(new Date());
    }
}
