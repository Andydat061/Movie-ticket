package com.example.final_software.ProjectionManager.QLTheLoai_PhimChieu.PhimChieu;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.final_software.Models.Movie;
import com.example.final_software.R;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;

public class ListPhimChieuAdapter extends RecyclerView.Adapter<ListPhimChieuAdapter.MyViewHolder>{
    private Context context;
    private ArrayList<Movie> arrMovie;

    public ListPhimChieuAdapter(Context context, ArrayList<Movie> arrMovie) {
        this.context = context;
        this.arrMovie = arrMovie;
    }

    @NonNull
    @Override
    public ListPhimChieuAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_movie, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ListPhimChieuAdapter.MyViewHolder holder, int position) {
        holder.getName.setText("Tên phim: " + arrMovie.get(position).Name);
        holder.getDate.setText("Ngày phát hành: " + arrMovie.get(position).Date);
        holder.getTime.setText("Thời lượng: " + arrMovie.get(position).Time+ " phút");
        holder.getDirector.setText("Đạo diễn: " + arrMovie.get(position).Director);
        holder.getActor.setText("Diễn viên: "+ arrMovie.get(position).Actor);
        holder.get_image.setImageBitmap(arrMovie.get(position).Image);
        holder.getLanguage.setText("Ngôn ngữ: "+ arrMovie.get(position).Language);
        holder.mainlayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ByteArrayOutputStream stream = new ByteArrayOutputStream();
                arrMovie.get(position).Image.compress(Bitmap.CompressFormat.JPEG, 50, stream);
                byte[] imageByte = stream.toByteArray();
                Intent a = new Intent(holder.itemView.getContext(), DetailMovieActivity.class);
                a.putExtra("tenphim", String.valueOf(arrMovie.get(position).Name));
                a.putExtra("ngayphathanh", String.valueOf(arrMovie.get(position).Date));
                a.putExtra("thoiluong", String.valueOf(arrMovie.get(position).Time));
                a.putExtra("daodien", String.valueOf(arrMovie.get(position).Director));
                a.putExtra("anhphim", imageByte);
                a.putExtra("dienvien", String.valueOf(arrMovie.get(position).Actor));
                a.putExtra("ngonngu", String.valueOf(arrMovie.get(position).Language));
                holder.itemView.getContext().startActivity(a);
            }
        });
    }

    @Override
    public int getItemCount() {
        return arrMovie == null ? 0 : arrMovie.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView getName, getDate,getTime, getDirector, getActor, getLanguage;
        ImageView get_image;
        LinearLayout mainlayout;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            getName = itemView.findViewById(R.id.item_phimchieu_Name);
            getDate = itemView.findViewById(R.id.item_phimchieu_Date);
            getTime = itemView.findViewById(R.id.item_phimchieu_Time);
            getDirector = itemView.findViewById(R.id.item_phimchieu_Director);
            get_image = itemView.findViewById(R.id.item_phimchieu_Image);
            getActor = itemView.findViewById(R.id.item_phimchieu_Actor);
            getLanguage = itemView.findViewById(R.id.item_phimchieu_Language);
            mainlayout = itemView.findViewById(R.id.item_phimchieu_mainlayout);
        }
    }
}
