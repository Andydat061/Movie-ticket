package com.example.final_software.ProjectionManager.FragmentMain;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.final_software.DBHelper;
import com.example.final_software.ProjectionManager.QLTheLoai_PhimChieu.AddCategory;
import com.example.final_software.ProjectionManager.QLTheLoai_PhimChieu.Category;
import com.example.final_software.ProjectionManager.QLTheLoai_PhimChieu.CategoryAdapter;
import com.example.final_software.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;


public class ListTheLoaiPhimFragment extends Fragment {
    RecyclerView recyclerView;
    FloatingActionButton add_button;

    DBHelper myDB;
    ArrayList<String> theloai_id, theloai_ten, theloai_mota;
    CategoryAdapter categoryAdapter;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        Toolbar actionBar = (Toolbar) getActivity().findViewById(R.id.materialToolbar_pm);
        actionBar.setTitle("Danh sách thể loại phim");
        actionBar.setBackgroundColor(Color.WHITE);
        ((AppCompatActivity) getActivity()).setSupportActionBar(actionBar);
        return inflater.inflate(R.layout.fragment_list_the_loai_phim, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        recyclerView = view.findViewById(R.id.recyclerView);
        add_button = view.findViewById(R.id.add_button);
        add_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(), AddCategory.class);
                startActivity(intent);
            }
        });

        myDB = new DBHelper(getActivity());
        theloai_id=new ArrayList<>();
        theloai_ten=new ArrayList<>();
        theloai_mota=new ArrayList<>();
        storeDataInArray();
        categoryAdapter = new CategoryAdapter(getActivity(), getContext(),theloai_id, theloai_ten, theloai_mota);
        recyclerView.setAdapter(categoryAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
    }
    public void storeDataInArray() {
        Cursor cursor = myDB.readAllData();
        if (cursor.getCount() == 0) {
            Toast.makeText(getActivity(), "Không có dữ liệu.", Toast.LENGTH_SHORT).show();
        } else {
            while (cursor.moveToNext()) {
                theloai_id.add(cursor.getString(0));
                theloai_ten.add(cursor.getString(1));
                theloai_mota.add(cursor.getString(2));
            }
        }
    }
}