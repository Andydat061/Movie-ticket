package com.example.final_software.Models;


import android.graphics.Bitmap;

public class Movie {

    public int Id;
    public String Name;
    public String Date;
    public int Time;
    public String Director;
    public String Actor;
    public String Language;
    public Bitmap Image;

    public Movie() {
    }

    public Movie(String Name, String Date, int Time,String Director,String Actor, String Language, Bitmap Image) {
        this.Name = Name;
        this.Date= Date;
        this.Time = Time;
        this.Director = Director;
        this.Actor = Actor;
        this.Language= Language;
        this.Image=Image;

    }

    public Movie(int id, String name, String date, int time, String director, String actor, String language, Bitmap image) {
        Id = id;
        Name = name;
        Date = date;
        Time = time;
        Director = director;
        Actor = actor;
        Language = language;
        Image = image;
    }
}
