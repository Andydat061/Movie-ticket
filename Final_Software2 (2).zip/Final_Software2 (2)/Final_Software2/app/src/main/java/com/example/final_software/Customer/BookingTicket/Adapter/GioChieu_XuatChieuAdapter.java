package com.example.final_software.Customer.BookingTicket.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.final_software.Customer.BookingTicket.Ghe_XuatChieu_CTMActivity;
import com.example.final_software.Models.XuatChieu;
import com.example.final_software.R;

import java.util.ArrayList;

public class GioChieu_XuatChieuAdapter extends RecyclerView.Adapter<GioChieu_XuatChieuAdapter.MyViewHolder>{
    Context context;
    ArrayList<XuatChieu> listXuatChieu;

    public GioChieu_XuatChieuAdapter(Context context, ArrayList<XuatChieu> listXuatChieu) {
        this.context = context;
        this.listXuatChieu = listXuatChieu;
    }

    @NonNull
    @Override
    public GioChieu_XuatChieuAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_giochieu, parent, false);
        return new GioChieu_XuatChieuAdapter.MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull GioChieu_XuatChieuAdapter.MyViewHolder holder, int position) {
        holder.txt_ngaychieu.setText(listXuatChieu.get(position).NgayChieu);
        holder.txt_tgbd_tgkt.setText(listXuatChieu.get(position).ThoiGianBatDau + " ~ " + listXuatChieu.get(position).ThoiGianKetThuc);
        holder.main_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent a = new Intent(context, Ghe_XuatChieu_CTMActivity.class);
                a.putExtra("idxuatchieu", listXuatChieu.get(position).IDXuatChieu);
                a.putExtra("giave", listXuatChieu.get(position).GiaVe);
                a.putExtra("ngaychieu", listXuatChieu.get(position).NgayChieu);
                a.putExtra("thoigianchieu", listXuatChieu.get(position).ThoiGianBatDau + " ~ " + listXuatChieu.get(position).ThoiGianKetThuc);
                holder.itemView.getContext().startActivity(a);
            }
        });
    }

    @Override
    public int getItemCount() {
        return listXuatChieu == null ? 0 : listXuatChieu.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView txt_ngaychieu, txt_tgbd_tgkt;
        LinearLayout main_layout;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            txt_ngaychieu = itemView.findViewById(R.id.txt_giochieu_ngaychieu);
            txt_tgbd_tgkt = itemView.findViewById(R.id.txt_giochieu_total);
            main_layout = itemView.findViewById(R.id.giochieu_mainLayout);
        }
    }
}
