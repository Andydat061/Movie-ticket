package com.example.final_software;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Bitmap;
import android.widget.EditText;
import android.widget.Toast;

import com.example.final_software.Models.CT_VeXemPhim;
import com.example.final_software.Models.DiaDiemChieu;
import com.example.final_software.Models.Ghe_XuatChieu;
import com.example.final_software.Models.KhieuNai;
import com.example.final_software.Models.Movie;
import com.example.final_software.Models.PhanHoiKhieuNai;
import com.example.final_software.Models.TaiKhoanKhachHang;
import com.example.final_software.Models.VeXemPhim;
import com.example.final_software.Models.XuatChieu;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;

public class DBHelper extends SQLiteOpenHelper {
    private final Context context;
    private static final String DB_Name = "KHDCinemas";
    private static final int DB_Version = 1;
    private final String[] table_name;


    private byte[] imagebytearr;
    private ByteArrayOutputStream byteArrayOutputStream;
    public DBHelper(Context context) {
        super(context, DB_Name, null, DB_Version);
        this.context = context;
        table_name = new String[]{"TaiKhoanKhachHang", "TaiKhoanAdmin",
                "DiaDiemChieu", "RapChieu", "Ghe",
                "TheLoaiPhim", "PhimChieu", "TheLoai_Phim",
                "XuatChieu", "GheXuatChieu", "VeXemPhim",
                "SanPham", "HoaDonSanPham", "CT_HoaDon",
                "KhieuNai", "PhanHoiKhieuNai", "ChucVu"
        };
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        // create table TaiKhoanKhachHang
//        String query = "CREATE TABLE "+table_name[0]+" ("+customer_column[0]+" INTEGER PRIMARY KEY AUTOINCREMENT, "+customer_column[1]+" TEXT, "+customer_column[2]+" TEXT, "+customer_column[3]+" TEXT, " +customer_column[4]+" TEXT, "+customer_column[5]+" TEXT, "+customer_column[6]+" TEXT, "+customer_column[7]+" TEXT, "+customer_column[8]+" INTEGER, "+customer_column[9]+" TEXT);";
//        db.execSQL(query);
//        // create table TaiKhoanNguoiDung
//        query = "CREATE TABLE "+table_name[1]+" ("+admin_column[0]+" INTEGER PRIMARY KEY AUTOINCREMENT, "+admin_column[1]+" TEXT, "+admin_column[2]+" TEXT, "+admin_column[3]+" TEXT);";
//        db.execSQL(query);
//        // create table XuatChieu
//        query = "CREATE TABLE "+table_name[8]+" ("+xuatchieu_column[0]+" INTEGER PRIMARY KEY AUTOINCREMENT, "+xuatchieu_column[1]+" TEXT, "+xuatchieu_column[2]+" INT, "+admin_column[3]+" INT, "+admin_column[4]+" INT, "+admin_column[5]+" INT);";
//        db.execSQL(query);
        String query = "create table TaiKhoan(\n" +
                "\tIDTaikhoan INTEGER PRIMARY KEY AUTOINCREMENT,\n" +
                "\tTaikhoan TEXT,\n" +
                "\tMatkhau TEXT,\n" +
                "\tHoTen TEXT,\n" +
                "\tGioiTinh TEXT,\n" +
                "\tNgaySinh TEXT,\n" +
                "\tSoDienThoai TEXT,\n" +
                "\tEmail TEXT,\n" +
                "\tDiemThe REAL,\n" +
                "\tCapBac TEXT\n" +
                ");\n";
        db.execSQL(query);
        query = "create table TheLoaiPhim(\n" +
                "\tIDTheLoai INTEGER PRIMARY KEY AUTOINCREMENT,\n" +
                "\tTenTheLoai TEXT,\n" +
                "\tMoTa TEXT\n" +
                ");\n";
        db.execSQL(query);
        query = "create table PhimChieu(\n" +
                "\tIDPhim INTEGER PRIMARY KEY AUTOINCREMENT,\n" +
                "\tTenPhim TEXT,\n" +
                "\tAnhQC BLOB,\n" +
                "\tVideoQC BLOB,\n" +
                "\tNgayPhatHanh datetime,\n" +
                "\tGioChieu INTEGER,\n" +
                "\tDaoDien TEXT,\n" +
                "\tDienVien TEXT,\n" +
                "\tNgonNgu TEXT\n" +
                ");\n";
        db.execSQL(query);
        query = "create table TheLoai_Phim(\n" +
                "\tTheLoaiID int,\n" +
                "\tPhimID int,\n" +
                "\tForeign key (TheLoaiID) references TheLoaiPhim(IDTheLoai),\n" +
                "\tForeign key (PhimID) references PhimChieu(IDPhim)\n" +
                ");\n";
        db.execSQL(query);
        query = "create table DiaDiemChieu(\n" +
                "\tIDDiaDiem INTEGER PRIMARY KEY AUTOINCREMENT,\n" +
                "\tTenDiaDiem TEXT,\n" +
                "\tSoluongRap INTEGER,\n" +
                "\tMoTa TEXT\n" +
                ");\n";
        db.execSQL(query);
        query = "create table RapPhim(\n" +
                "\tIDRap INTEGER PRIMARY KEY AUTOINCREMENT,\n" +
                "\tTenRap TEXT,\n" +
                "\tSoTTRap INTEGER,\n" +
                "\tDiaDiemRap INTEGER,\n" +
                "\tSoluongGhe INTEGER,\n" +
                "\tSoluongGheVip INTEGER,\n" +
                "\tForeign key (DiaDiemRap) references DiaDiemChieu(IDDiaDiem)\n" +
                ");\n";
        db.execSQL(query);
        query = "create table Ghe(\n" +
                "\tIDGhe INTEGER PRIMARY KEY AUTOINCREMENT,\n" +
                "\tMaGhe TEXT,\n" +
                "\tLoaiGhe TEXT,\n" +
                "\tRapID INTEGER,\n" +
                "\tForeign key (RapID) references RapPhim(IDRap)\n" +
                ");\n";
        db.execSQL(query);
        query = "create table XuatChieu(\n" +
                "\tIDXuatChieu INTEGER PRIMARY KEY AUTOINCREMENT,\n" +
                "\tNgayChieu date,\n" +
                "\tThoiGianBatDau time,\n" +
                "\tThoiGianKetThuc time,\n" +
                "\tRapChieu INTEGER,\n" +
                "\tPhimID INTEGER,\n" +
                "\tGiaVe INTEGER,\n" +
                "\tForeign key (RapChieu) references RapPhim(IDRap),\n" +
                "\tForeign key (PhimID) references PhimChieu(IDPhim)\n" +
                ");\n";
        db.execSQL(query);
        query = "create table Ghe_XuatChieu(\n" +
                "\tIDGhe_XuatChieu INTEGER PRIMARY KEY AUTOINCREMENT,\n" +
                "\tGheID INTEGER,\n" +
                "\tXuatChieuID INTEGER,\n" +
                "\tTrangThaiGhe TEXT,\n" +
                "\tForeign key (GheID) references Ghe(IDGhe),\n" +
                "\tForeign key (XuatChieuID) references XuatChieu(IDXuatChieu)\n" +
                ");\n";
        db.execSQL(query);
        query = "create table VeXemPhim(\n" +
                "\tIDVe INTEGER PRIMARY KEY AUTOINCREMENT,\n" +
                "\tTaiKhoanID INTEGER,\n" +
                "\tGiaVe INTEGER,\n" +
                "\tNgayMua datetime,\n" +
                "\tTrangThaiVe TEXT,\n" +
                "\tFOREIGN KEY (TaiKhoanID) references TaiKhoan(IDTaikhoan)\n" +
                ");\n";
        db.execSQL(query);
        query = "create table CT_VeXemPhim(\n" +
                "\tVeID INTEGER,\n" +
                "\tGheXemPhim INTEGER,\n" +
                "\tForeign key (GheXemPhim) references Ghe_XuatChieu(IDGhe_XuatChieu),\n" +
                "\tForeign key (VeID) references VeXemPhim(IDVe)\n" +
                ");\n";
        db.execSQL(query);
        query = "create table SanPham(\n" +
                "\tIDSanPham INTEGER PRIMARY KEY AUTOINCREMENT,\n" +
                "\tTenSanPham TEXT,\n" +
                "\tGiaSanPham REAL,\n" +
                "\tMotaSanPham TEXT\n" +
                ");\n";
        db.execSQL(query);
        query = "create table HoaDon_SanPham(\n" +
                "\tIDHoaDonSanPham INTEGER PRIMARY KEY AUTOINCREMENT,\n" +
                "\tChiTietHoaDon TEXT,\n" +
                "\tTaiKhoanID INTEGER,\n" +
                "\tTongTien REAL,\n" +
                "\tNgayMua datetime,\n" +
                "\tTrangThaiHoaDon TEXT,\n" +
                "\tForeign key (TaiKhoanID) references TaiKhoan(IDTaiKhoan)\n" +
                ");\n";
        db.execSQL(query);
        query = "create table CT_HoaDon_SanPham(\n" +
                "\tHoaDonSanPhamID INTEGER,\n" +
                "\tSanPhamID INTEGER,\n" +
                "\tSoLuong INTEGER,\n" +
                "\tForeign key (HoaDonSanPhamID) references HoaDon_SanPham(IDHoaDonSanPham),\n" +
                "\tForeign key (SanPhamID) references SanPham(IDSanPham)\n" +
                ");\n";
        db.execSQL(query);
        query = "create table BaoCaoDoanhThuNam(\n" +
                "\tNam INTEGER primary key,\n" +
                "\tTongDoanhThuNam REAL,\n" +
                "\tTrangThaiBaoCao TEXT\n" +
                ");\n";
        db.execSQL(query);
        query = "create table BaoCaoDoanhThuThang(\n" +
                "\tIDBaoCao INTEGER PRIMARY KEY AUTOINCREMENT,\n" +
                "\tThang INTEGER,\n" +
                "\tTongDoanhThuThang REAL,\n" +
                "\tTrangThaiBaoCao TEXT,\n" +
                "\tNam INTEGER,\n" +
                "\tforeign key (Nam) references BaoCaoDoanhThuNam(Nam)\n" +
                ");\n";
        db.execSQL(query);
        query = "create table CT_BaoCao_XuatChieu(\n" +
                "\tBaoCaoID INTEGER,\n" +
                "\tXuatChieuID INTEGER,\n" +
                "\tSoLuongVeDaBan INTEGER,\n" +
                "\tTongThuXuatChieu REAL,\n" +
                "\tPrimary key(BaoCaoID, XuatChieuID),\n" +
                "\tforeign key(BaoCaoID) references BaoCaoDoanhThuThang(IDBaoCao),\n" +
                "\tforeign key(XuatChieuID) references XuatChieu(IDXuatChieu)\n" +
                ");\n";
        db.execSQL(query);
        query = "create table CT_BaoCao_SanPham(\n" +
                "\tBaoCaoID INTEGER,\n" +
                "\tSanPhamID INTEGER,\n" +
                "\tSoLuongSanPhamDaBan INTEGER,\n" +
                "\tTongThuSanPham REAL,\n" +
                "\tPrimary key(BaoCaoID, SanPhamID),\n" +
                "\tforeign key(BaoCaoID) references BaoCaoDoanhThuThang(IDBaoCao),\n" +
                "\tforeign key(SanPhamID) references SanPham(IDSanPham)\n" +
                ");\n";
        db.execSQL(query);
        query = "create table ChucVu(\n" +
                "\tMaChucVu TEXT Primary key,\n" +
                "\tTenChucVu TEXT,\n" +
                "\tMoTaChucVu TEXT\n" +
                ");\n";
        db.execSQL(query);
        query = "create table TaiKhoanNguoiDung(\n" +
                "\tMaTaiKhoanND INTEGER PRIMARY KEY AUTOINCREMENT,\n" +
                "\tTenDangNhap TEXT,\n" +
                "\tMatKhau TEXT,\n" +
                "\tChucVu TEXT,\n" +
                "\tforeign key (ChucVu) references ChucVu(MaChucVu)\n" +
                ");\n";
        db.execSQL(query);
        query = "create table KhieuNai(\n" +
                "\tMaKhieuNai INTEGER PRIMARY KEY AUTOINCREMENT,\n" +
                "\tDichVu TEXT,\n" +
                "\tMoTaChiTiet TEXT,\n" +
                "\tGoiYKhacPhuc TEXT,\n" +
                "\tNgayKhieuNai datetime,\n" +
                "\tTrangThaiKhieuNai TEXT,\n" +
                "\tNguoiKN INTEGER,\n" +
                "\tHinhAnh BLOB,\n" +
                "\tforeign key (NguoiKN) references TaiKhoan(IDTaiKhoan)\n" +
                ");\n";
        db.execSQL(query);
        query = "create table PhanHoiKhieuNai(\n" +
                "\tMaPhanHoi INTEGER PRIMARY KEY AUTOINCREMENT,\n" +
                "\tTieuDe TEXT,\n" +
                "\tDichVu TEXT,\n" +
                "\tPhanHoiCuThe TEXT,\n" +
                "\tNgayPhanHoi datetime,\n" +
                "\tKhieuNaiID INTEGER,\n" +
                "\tNguoiPH INTEGER,\n" +
                "\tforeign key (KhieuNaiID) references KhieuNai(MaKhieuNai),\n" +
                "\tforeign key (NguoiPH) references TaiKhoanNguoiDung(MaTaiKhoanND)\n" +
                ");\n";
        db.execSQL(query);
        query = "insert INTO ChucVu values(0 ,'AccountManager', 'None'), (1,'ProjectionManager', 'None'), (2,'CustomerServiceAgent', 'None'), (3,'Accountant', 'None');";
        db.execSQL(query);
        query = "insert into TaiKhoanNguoiDung values(0, 'admin1', '12345', 0),(1, 'admin2', '12345', 1),(2, 'admin3', '12345', 2),(3, 'admin4', '12345', 3);";
        db.execSQL(query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS "+table_name[0]);
        db.execSQL("DROP TABLE IF EXISTS "+table_name[1]);
        onCreate(db);
    }

    // CRUD XuatChieu
    // Create Xuat Chieu
    public Cursor get_ALL_XuatChieu(){
        String query = "SELECT * FROM XuatChieu";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        if(db != null)
            cursor = db.rawQuery(query,null);
        return cursor;
    }
    public Cursor get_Phim_For_XuatChieu(int ID){
        String query = "SELECT TenPhim FROM XuatChieu, PhimChieu where XuatChieu.PhimID = PhimChieu.IDPhim and IDXuatChieu = " + ID;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        if(db != null)
            cursor = db.rawQuery(query,null);
        return cursor;
    }
    public Cursor get_ImagePhim_For_XuatChieu(int ID){
        String query = "SELECT AnhQC FROM XuatChieu, PhimChieu where XuatChieu.PhimID = PhimChieu.IDPhim and IDXuatChieu = " + ID;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        if(db != null)
            cursor = db.rawQuery(query,null);
        return cursor;
    }
    public Cursor get_Rap_ForXuatChieu(int ID){
        String query = "SELECT TenRap from XuatChieu, RapPhim where RapChieu = RapPhim.IDRap and XuatChieu.IDXuatChieu = "+ ID;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        if(db != null)
            cursor = db.rawQuery(query,null);
        return cursor;
    }
    public Cursor get_ID_Phim_By_Name(String nameMovie){
        String query = "select IDPhim, GioChieu from PhimChieu where TenPhim = '"+ nameMovie+"';";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        if(db != null)
            cursor = db.rawQuery(query,null);
        return cursor;
    }
    public Cursor get_ID_Rap_By_Name(String nameTheaters){
        String query = "SELECT IDRap FROM RapPhim WHERE TenRap = '"+ nameTheaters+"';";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        if(db != null)
            cursor = db.rawQuery(query,null);
        return cursor;
    }
    public Cursor get_All_Name_Phim(){
        String query = "SELECT TENPHIM FROM PHIMCHIEU";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        if(db != null)
            cursor = db.rawQuery(query,null);
        return cursor;
    }
    public Cursor get_All_Name_Rap(){
        String query = "SELECT TenRap FROM RapPhim";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        if(db != null)
            cursor = db.rawQuery(query,null);
        return cursor;
    }
    public boolean addTaiKhoan(String TaiKhoan, String MatKhau, String HoTen, String GioiTinh, String NgaySinh, String SoDienThoai, String Email)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("TaiKhoan", TaiKhoan);
        values.put("MatKhau", MatKhau);
        values.put("HoTen", HoTen);
        values.put("GioiTinh", GioiTinh);
        values.put("NgaySinh",NgaySinh);
        values.put("SoDienThoai",SoDienThoai);
        values.put("Email",Email);
        long result = db.insert("TaiKhoanKhachHang",null,values);
        if (result==-1) return false;
        else return true;
    }
    public boolean checkUsername(String TaiKhoan)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("select * from TaiKhoanKhachHang where TaiKhoan =?", new String[]{TaiKhoan});
        if (cursor.getCount()>0)
            return true;
        else return false;

    }
    public void add_XuatChieu(XuatChieu a){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("NgayChieu", a.NgayChieu.toString());
        cv.put("ThoiGianBatDau", a.ThoiGianBatDau.toString());
        cv.put("ThoiGianKetThuc", a.ThoiGianKetThuc.toString());
        cv.put("RapChieu", a.RapChieu);
        cv.put("PhimID", a.PhimChieu);
        cv.put("GiaVe", a.GiaVe);
        try {
            db.insert("XuatChieu", null, cv);
        }
        catch (Exception e){
            Toast.makeText(context, e.toString(), Toast.LENGTH_SHORT).show();
        }
    }
    public Cursor get_XuatChieuTrung(String NgayChieu, String TGBD, int rapChieu){
        String query = "select * from XuatChieu where NgayChieu = '"+NgayChieu+"' and ThoiGianBatDau <= '"+ TGBD +"' and RapChieu = "+ rapChieu +" and ThoiGianKetThuc >= '"+TGBD+"'";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        if(db != null)
            cursor = db.rawQuery(query,null);
        return cursor;
    }
    public Cursor get_NewXuatChieu(){
        String query = "select IDXuatChieu from XuatChieu order by IDXuatChieu desc Limit 1 ";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        if(db != null)
            cursor = db.rawQuery(query,null);
        return cursor;
    }
    public void update_XuatChieu(XuatChieu a){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put("NgayChieu", a.NgayChieu.toString());
        cv.put("ThoiGianBatDau", a.ThoiGianBatDau.toString());
        cv.put("ThoiGianKetThuc", a.ThoiGianKetThuc.toString());
        cv.put("RapChieu", a.RapChieu);
        cv.put("PhimChieu", a.PhimChieu);
        db.update("XuatChieu",cv,"IDXuatChieu=?", new String[]{String.valueOf(a.IDXuatChieu)});
    }
    public void delete_XuatChieu(int ID){
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete("XuatChieu", "IDXuatChieu=?", new String[]{String.valueOf(ID)});
    }
    //
    // CRUD Ghe_XuatChieu
    public Cursor get_All_Ghe_Rap(int IDRap){
        String query = "select * from Ghe where RapID = " + IDRap;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        if(db != null)
            cursor = db.rawQuery(query,null);
        return cursor;
    }
    public Cursor get_ALL_Ghe_XuatChieu(int IDXuatChieu){
        String query = "SELECT * FROM Ghe_XuatChieu WHERE XuatChieuID = " + IDXuatChieu;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor_xuatchieu = null;
        if(db != null)
            cursor_xuatchieu = db.rawQuery(query,null);
        return cursor_xuatchieu;
    }
    public void add_Ghe_XuatChieu(Ghe_XuatChieu a){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("GheID", a.GheID);
        cv.put("XuatChieuID", a.XuatChieuID);
        cv.put("TrangThaiGhe", a.TrangThaiGhe);
        db.insert("Ghe_XuatChieu",null,cv);
    }
    public void update_Ghe_XuatChieu(Ghe_XuatChieu a){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put("GheID", a.GheID);
        cv.put("XuatChieuID", a.XuatChieuID);
        cv.put("TrangThaiGhe", a.TrangThaiGhe);
        db.update("Ghe_XuatChieu",cv,"IDGhe_XuatChieu=?", new String[]{String.valueOf(a.IDGhe_XuatChieu)});
    }
    public void delete_Ghe_XuatChieu(int ID){
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete("Ghe_XuatChieu", "IDGhe_XuatChieu=?", new String[]{String.valueOf(ID)});
    }
    //Booking Ticket

    public Cursor getPhimChieu_Home(){
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "select IDPhim, TenPhim, AnhQC, NgayChieu from XuatChieu, PhimChieu where XuatChieu.PhimID = PhimChieu.IDPhim";
        Cursor cursor = null;
        if(db != null)
            cursor = db.rawQuery(query,null);
        return cursor;
    }
    public String getCurrentDate(){
        String query = "select CURRENT_DATE";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(query, null);
        cursor.moveToNext();
        String a = cursor.getString(0);
        return a.split("-")[2] + "/"+ a.split("-")[1] +"/"+a.split("-")[0];
    }
    public Cursor getDiaDiemChieu_IDPhim(int IDPhim){
        String query = "select IDDiaDiem, TenDiaDiem, DiaDiemChieu.SoluongRap, MoTa \n" +
                "from DiaDiemChieu, RapPhim, XuatChieu\n" +
                "where DiaDiemChieu.IDDiaDiem = RapPhim.DiaDiemRap\n" +
                "and XuatChieu.RapChieu = RapPhim.IDRap\n" +
                "and XuatChieu.PhimID = "+ IDPhim +"\n" +
                "group by TenDiaDiem\n" +
                "order by IDDiaDiem";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        if(db != null){
            cursor = db.rawQuery(query, null);
        }
        return cursor;
    }
    public Cursor getXuatChieu_IDDiaDiem(int IDDiaDiem, int IDPhim){
        String query = "select IDXuatChieu, NgayChieu, ThoiGianBatDau, ThoiGianKetThuc, RapChieu, PhimID, GiaVe\n" +
                "from XuatChieu, RapPhim\n" +
                "where XuatChieu.RapChieu = RapPhim.IDRap\n" +
                "and RapPhim.DiaDiemRap = "+ IDDiaDiem +"\n" +
                "and XuatChieu.PhimID = "+ IDPhim +"\n" +
                "order by NgayChieu asc";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        if(db != null){
            cursor = db.rawQuery(query, null);
        }
        return cursor;
    }
    public Cursor getTenDiaDiemAndTenPhim_IDXuatChieu(int IDXuatChieu){
        String query = "select TenPhim, TenDiaDiem \n" +
                "from XuatChieu, PhimChieu, DiaDiemChieu, RapPhim\n" +
                "where XuatChieu.PhimID = PhimChieu.IDPhim\n" +
                "and XuatChieu.RapChieu = RapPhim.IDRap\n" +
                "and RapPhim.DiaDiemRap = DiaDiemChieu.IDDiaDiem\n" +
                "AND XuatChieu.IDXuatChieu = "+ IDXuatChieu;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        if(db != null){
            cursor = db.rawQuery(query, null);
        }
        return cursor;
    }
    //Khiếu nại
    public long add_KhieuNai(KhieuNai khieuNai) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("DichVu", khieuNai.getDichVu());
        values.put("MoTaChiTiet", khieuNai.getMoTaChiTiet());
        values.put("GoiYKhacPhuc", khieuNai.getGoiYKhacPhuc());
        values.put("NgayKhieuNai", khieuNai.getNgayKhieuNai());
        values.put("TrangThaiKhieuNai", khieuNai.getTrangThaiKhieuNai());
        values.put("NguoiKN", khieuNai.getNguoiKN());
        values.put("HinhAnh", khieuNai.getHinhAnh()); // Add this line

        // Insert the row and get the row ID
        long result = db.insert("KhieuNai", null, values);
        db.close(); // Close the database connection
        return result;
    }

    //get tất cả khiếu nại
    @SuppressLint("Range")
    public ArrayList<KhieuNai> getAllKhieuNai() {
        ArrayList<KhieuNai> khieuNaiList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM KhieuNai";

        // Thực thi câu lệnh SQL
        Cursor cursor = db.rawQuery(query, null);

        // Kiểm tra nếu có dữ liệu
        if (cursor.moveToFirst()) {
            do {
                KhieuNai khieuNai = new KhieuNai();
                khieuNai.setMaKhieuNai(cursor.getInt(cursor.getColumnIndex("MaKhieuNai")));
                khieuNai.setDichVu(cursor.getString(cursor.getColumnIndex("DichVu")));
                khieuNai.setMoTaChiTiet(cursor.getString(cursor.getColumnIndex("MoTaChiTiet")));
                khieuNai.setGoiYKhacPhuc(cursor.getString(cursor.getColumnIndex("GoiYKhacPhuc")));
                khieuNai.setNgayKhieuNai(cursor.getString(cursor.getColumnIndex("NgayKhieuNai")));
                khieuNai.setTrangThaiKhieuNai(cursor.getString(cursor.getColumnIndex("TrangThaiKhieuNai")));
                khieuNai.setNguoiKN(cursor.getInt(cursor.getColumnIndex("NguoiKN")));
                khieuNai.setHinhAnh(cursor.getBlob(cursor.getColumnIndex("HinhAnh")));
                khieuNaiList.add(khieuNai);
            } while (cursor.moveToNext());
        }

        // Đóng con trỏ và cơ sở dữ liệu
        cursor.close();
        db.close();

        return khieuNaiList;
    }
    @SuppressLint("Range")
    public KhieuNai getKhieuNaiByID(int maKhieuNai) {
        SQLiteDatabase db = this.getReadableDatabase();
        KhieuNai khieuNai = null;

        // Câu lệnh truy vấn SQL với tham số
        String query = "SELECT * FROM KhieuNai WHERE MaKhieuNai = ?";

        // Thực thi truy vấn và lấy kết quả
        Cursor cursor = db.rawQuery(query, new String[]{String.valueOf(maKhieuNai)});

        if (cursor.moveToFirst()) {
            // Chuyển đổi dữ liệu từ Cursor thành đối tượng KhieuNai
            khieuNai = new KhieuNai();
            khieuNai.setMaKhieuNai(cursor.getInt(cursor.getColumnIndex("MaKhieuNai")));
            khieuNai.setDichVu(cursor.getString(cursor.getColumnIndex("DichVu")));
            khieuNai.setMoTaChiTiet(cursor.getString(cursor.getColumnIndex("MoTaChiTiet")));
            khieuNai.setGoiYKhacPhuc(cursor.getString(cursor.getColumnIndex("GoiYKhacPhuc")));
            khieuNai.setNgayKhieuNai(cursor.getString(cursor.getColumnIndex("NgayKhieuNai")));
            khieuNai.setTrangThaiKhieuNai(cursor.getString(cursor.getColumnIndex("TrangThaiKhieuNai")));
            khieuNai.setNguoiKN(cursor.getInt(cursor.getColumnIndex("NguoiKN")));
            khieuNai.setHinhAnh(cursor.getBlob(cursor.getColumnIndex("HinhAnh")));
        }

        cursor.close(); // Đóng con trỏ
        db.close(); // Đóng cơ sở dữ liệu

        return khieuNai;
    }
    public long addPhanHoiKhieuNai(PhanHoiKhieuNai phanHoiKhieuNai) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("TieuDe", phanHoiKhieuNai.getTieuDe());
        values.put("DichVu", phanHoiKhieuNai.getDichVu());
        values.put("PhanHoiCuThe", phanHoiKhieuNai.getPhanHoiCuThe());
        values.put("NgayPhanHoi", phanHoiKhieuNai.getNgayPhanHoi());
        values.put("KhieuNaiID", phanHoiKhieuNai.getKhieuNaiID());
        values.put("NguoiPH", phanHoiKhieuNai.getNguoiPH());


        long result = db.insert("PhanHoiKhieuNai", null, values);
        if (result != -1) {
            updateKhieuNaiStatus(phanHoiKhieuNai.getKhieuNaiID(), "Đã phản hồi");
        }
        db.close(); // Close the database connection
        return result;
    }

    //Hàm cập nhật trạng thái khiếu nại
    private void updateKhieuNaiStatus(int khieuNaiID, String status) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("TrangThaiKhieuNai", status);


        db.update("KhieuNai", values, "MaKhieuNai" + " = ?", new String[]{String.valueOf(khieuNaiID)});
        db.close();
    }

    @SuppressLint("Range")
    public PhanHoiKhieuNai getPhanHoiByKhieuNaiID(int maKhieuNai) {
        SQLiteDatabase db = this.getReadableDatabase();
        PhanHoiKhieuNai phanHoiKhieuNai = null;

        // Câu lệnh truy vấn SQL với tham số
        String query = "SELECT * FROM PhanHoiKhieuNai WHERE KhieuNaiID = ?";

        // Thực thi truy vấn và lấy kết quả
        Cursor cursor = db.rawQuery(query, new String[]{String.valueOf(maKhieuNai)});

        if (cursor.moveToFirst()) {
            // Chuyển đổi dữ liệu từ Cursor thành đối tượng PhanHoiKhieuNai
            phanHoiKhieuNai = new PhanHoiKhieuNai(
                    cursor.getInt(cursor.getColumnIndex("MaPhanHoi")),
                    cursor.getString(cursor.getColumnIndex("TieuDe")),
                    cursor.getString(cursor.getColumnIndex("DichVu")),
                    cursor.getString(cursor.getColumnIndex("PhanHoiCuThe")),
                    cursor.getString(cursor.getColumnIndex("NgayPhanHoi")),
                    cursor.getInt(cursor.getColumnIndex("KhieuNaiID")),
                    cursor.getInt(cursor.getColumnIndex("NguoiPH"))
            );
        }

        cursor.close(); // Đóng con trỏ
        db.close(); // Đóng cơ sở dữ liệu

        return phanHoiKhieuNai;
    }
    // Thể loại phim
    public void addCategory(String name, String des) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put("TenTheLoai", name);
        cv.put("MoTa", des);
        long result = db.insert("TheLoaiPhim", null, cv);
        if (result == -1) {
            Toast.makeText(context, "Thêm thất bại", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(context, "Thêm thành công", Toast.LENGTH_SHORT).show();
        }
    }
    public Cursor readAllData() {
        String query = "SELECT * FROM TheLoaiPhim";
        SQLiteDatabase db=this.getReadableDatabase();

        Cursor cursor = null;
        if (db != null) {
            cursor = db.rawQuery(query, null);
        }
        return  cursor;
    }
    public void updateData(String row_id,String name, String description) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("TenTheLoai", name);
        cv.put("MoTa", description);

        long result = db.update("TheLoaiPhim", cv, "IDTheLoai=?", new String[]{row_id});
        if (result == -1) {
            Toast.makeText(context, "Cập nhật thất bại", Toast.LENGTH_SHORT).show();
        }else {
            Toast.makeText(context, "Cập nhật thành công", Toast.LENGTH_SHORT).show();
        }
    }
    public void deleteOneRow(String row_id) {
        SQLiteDatabase db= this.getWritableDatabase();
        long result = db.delete("TheLoaiPhim", "id=?", new String[]{row_id});
        if (result == -1) {
            Toast.makeText(context, "Xóa thất bại", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(context, "Xóa thành công", Toast.LENGTH_SHORT).show();
        }
    }
    //Phim chiếu
    public Cursor getMovie(){
        String query = "SELECT * from PhimChieu";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor;
        cursor = null;
        if(db != null)
            cursor = db.rawQuery(query,null);
        return cursor;
    }
    public Cursor getMovie_byName(String nameMovie){
        String query = "Select * from PhimChieu where TenPhim = '"+ nameMovie+"'";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor;
        cursor = null;
        if(db != null)
            cursor = db.rawQuery(query,null);
        return cursor;
    }
    public void createMovie(Movie a){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        Bitmap imageToStoreBitmap = a.Image;
        byteArrayOutputStream = new ByteArrayOutputStream();
        imageToStoreBitmap.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream);
        imagebytearr = byteArrayOutputStream.toByteArray();

        cv.put("TenPhim", a.Name);
        cv.put("NgayPhatHanh", a.Date);
        cv.put("GioChieu", a.Time);
        cv.put("DaoDien", a.Director);
        cv.put("DienVien", a.Actor);
        cv.put("NgonNgu", a.Language);
        cv.put("AnhQC", imagebytearr);
        db.insert("PhimChieu",null,cv);
    }

    //Địa điểm chiếu

    public Cursor getAllDiaDiem(){
        String query = "SELECT IDDiaDiem, TenDiaDiem FROM DIADIEMCHIEU";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        if(db != null){
            cursor = db.rawQuery(query, null);
            return cursor;
        }
        return cursor;
    }
    public void addDiaDiemChieu(DiaDiemChieu a){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put("TenDiaDiem", a.TenDiaDiem);
        cv.put("SoLuongRap", a.SoLuongRap);
        cv.put("MoTa", a.MoTa);

        db.insert("DiaDiemChieu",null,cv);
    }
    // Vé xem phim
    public  void addVeXemPhim(VeXemPhim a){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put("TaiKhoanID", a.TaiKhoanID);
        cv.put("GiaVe", a.GiaVe);
        cv.put("NgayMua", a.NgayMua);
        cv.put("TrangThaiVe", a.TrangThaiVe);

        db.insert("VeXemPhim",null,cv);
    }
    public Integer getIDNewVeXemPhim(){
        String query = "select IDVe from VeXemPhim order by IDVe desc Limit 1 ";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        cursor = db.rawQuery(query,null);
        cursor.moveToNext();
        int ID = cursor.getInt(0);
        return ID;
    }
    public  void addGhe_VeXemPhim(CT_VeXemPhim a){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put("GheXemPhim", a.IDGhe);
        cv.put("VeID", a.IDVe);

        db.insert("CT_VeXemPhim",null,cv);
    }
    public void updateGhe_XuatChieu(Integer IDGhe_XuatChieu, String TrangThaiGhe){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put("TrangThaiGhe", TrangThaiGhe);
        db.update("Ghe_XuatChieu",cv,"IDGhe_XuatChieu=?", new String[]{IDGhe_XuatChieu.toString()});
    }


}
