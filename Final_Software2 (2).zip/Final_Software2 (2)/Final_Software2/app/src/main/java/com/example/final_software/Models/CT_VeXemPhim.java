package com.example.final_software.Models;

public class CT_VeXemPhim {
    public int IDVe;
    public int IDGhe;

    public CT_VeXemPhim(int IDVe, int IDGhe) {
        this.IDVe = IDVe;
        this.IDGhe = IDGhe;
    }
}
