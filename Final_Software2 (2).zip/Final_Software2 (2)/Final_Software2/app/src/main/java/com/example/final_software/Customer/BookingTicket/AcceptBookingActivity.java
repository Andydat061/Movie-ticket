package com.example.final_software.Customer.BookingTicket;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.final_software.DBHelper;
import com.example.final_software.Models.PhimChieu;
import com.example.final_software.R;

public class AcceptBookingActivity extends AppCompatActivity {
    String ngayChieu, tgianChieu, tenPhim, tenDiadiem;
    int IDXuatchieu,TongTien;
    TextView txt_tenPhim, txt_diadiemchieu, txt_listMaGhe, txt_ngaychieu, txt_giochieu, txt_tonggiave;
    ImageView anhQC;
    DBHelper db;
    Button btn_gotoPayMent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_accept_booking);
        txt_tenPhim = findViewById(R.id.ticket_ctm_tenphim);
        txt_diadiemchieu = findViewById(R.id.ticket_ctm_diadiemchieu);
        txt_ngaychieu = findViewById(R.id.ticket_ctm_ngayChieu);
        txt_giochieu = findViewById(R.id.ticket_ctm_gioChieu);
        txt_tonggiave = findViewById(R.id.ticket_ctm_tongTien);
        txt_listMaGhe = findViewById(R.id.ticket_ctm_gheDaDat);
        anhQC = findViewById(R.id.ticket_ctm_anhqc);
        btn_gotoPayMent = findViewById(R.id.goto_Payment);
        db = new DBHelper(AcceptBookingActivity.this);
        set_getIntent();
        getImage();
        getInfor();
        btn_gotoPayMent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent a = new Intent(AcceptBookingActivity.this, Payment_CTMActivity.class);
                startActivity(a);
            }
        });
    }
    public void set_getIntent(){
        if(getIntent().hasExtra("idxuatchieu")
                && getIntent().hasExtra("tongtien")
                && getIntent().hasExtra("ngaychieu")
                && getIntent().hasExtra("thoigianchieu")
                && getIntent().hasExtra("tendiadiem")
                && getIntent().hasExtra("tenphim")){
            IDXuatchieu = getIntent().getIntExtra("idxuatchieu", 0);
            TongTien = getIntent().getIntExtra("tongtien", 0);
            ngayChieu = getIntent().getStringExtra("ngaychieu");
            tgianChieu = getIntent().getStringExtra("thoigianchieu");
            tenPhim = getIntent().getStringExtra("tenphim");
            tenDiadiem = getIntent().getStringExtra("tendiadiem");
        }
    }
    public void getImage(){
        Cursor cursor = db.get_ImagePhim_For_XuatChieu(IDXuatchieu);
        cursor.moveToNext();
        if(cursor.getBlob(0) == null){
            anhQC.setImageResource(R.drawable.tt_conan);
        }
        else{
            byte[] imagebyte = cursor.getBlob(0);
            Bitmap bitmap = BitmapFactory.decodeByteArray(imagebyte, 0, imagebyte.length);
            anhQC.setImageBitmap(bitmap);
        }
    }
    public void getInfor(){
        txt_tenPhim.setText(tenPhim);
        txt_diadiemchieu.setText("Địa điểm chiếu: "+tenDiadiem);
        txt_giochieu.setText("Giờ chiếu: "+tgianChieu);
        txt_ngaychieu.setText("Ngày chiếu: "+ngayChieu);
        txt_tonggiave.setText("Tổng thanh toán: "+TongTien + " đ");
        SharedPreferences sharedPreferences = AcceptBookingActivity.this.getSharedPreferences("BookingTicket", MODE_PRIVATE);
        String chuoiGhe_DaChon = sharedPreferences.getString("ListGheNgoi", "");
        txt_listMaGhe.setText("Ghế đã chọn: "+ chuoiGhe_DaChon);
    }
}