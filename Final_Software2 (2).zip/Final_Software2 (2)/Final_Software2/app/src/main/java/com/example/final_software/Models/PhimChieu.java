package com.example.final_software.Models;

import android.graphics.Bitmap;

public class PhimChieu {
    public  int IDPhim;
    public String TenPhim;
    public Bitmap AnhQC;
    public String NgayPhatHanh;
    public int GioChieu;
    public String DaoDien;
    public String DienVien;
    public String NgonNgu;

    public PhimChieu(int IDPhim, String tenPhim, Bitmap anhQC, String ngayPhatHanh, int gioChieu, String daoDien, String dienVien, String ngonNgu) {
        this.IDPhim = IDPhim;
        TenPhim = tenPhim;
        AnhQC = anhQC;
        NgayPhatHanh = ngayPhatHanh;
        GioChieu = gioChieu;
        DaoDien = daoDien;
        DienVien = dienVien;
        NgonNgu = ngonNgu;
    }

    public PhimChieu(String tenPhim, Bitmap anhQC, String ngayPhatHanh, int gioChieu, String daoDien, String dienVien, String ngonNgu) {
        TenPhim = tenPhim;
        AnhQC = anhQC;
        NgayPhatHanh = ngayPhatHanh;
        GioChieu = gioChieu;
        DaoDien = daoDien;
        DienVien = dienVien;
        NgonNgu = ngonNgu;
    }

    public PhimChieu(int IDPhim, String tenPhim, Bitmap anhQC) {
        this.IDPhim = IDPhim;
        TenPhim = tenPhim;
        AnhQC = anhQC;
    }
}
