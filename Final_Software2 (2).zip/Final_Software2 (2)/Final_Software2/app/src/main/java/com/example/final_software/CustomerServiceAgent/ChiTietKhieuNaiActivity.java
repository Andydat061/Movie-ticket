package com.example.final_software.CustomerServiceAgent;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.final_software.Customer.GuiKhieuNai.GuiKhieuNaiActivity;
import com.example.final_software.DBHelper;
import com.example.final_software.Models.KhieuNai;
import com.example.final_software.Models.PhimChieu;
import com.example.final_software.R;

public class ChiTietKhieuNaiActivity extends AppCompatActivity {

    private TextView textViewMaKhieuNai;
    private TextView textViewTenNguoiDung;
    private TextView textViewDichVu;
    private TextView textViewMoTaChiTiet;
    private TextView textViewNgayKhieuNai;
    private TextView textViewTrangThaiKhieuNai;
    //    private TextView textViewGoiYKhacPhuc;
    private TextView textViewLoaiKhieuNai;
    private TextView textViewTenPhim;

    private ImageView imageViewHinhAnh;
    private Button buttonPhanHoi;

    String tieuDe;
    String chiTiet;


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 1 && resultCode == RESULT_OK) {
            if (data != null && data.getBooleanExtra("UPDATE_STATUS", false)) {
                int maKhieuNai = getIntent().getIntExtra("MA_KHIEU_NAI", -1);
                DBHelper dbHelper = new DBHelper(this);
                KhieuNai khieuNai = dbHelper.getKhieuNaiByID(maKhieuNai);

                if (khieuNai != null) {
                    textViewTrangThaiKhieuNai.setText(khieuNai.getTrangThaiKhieuNai());
                    if (khieuNai.getTrangThaiKhieuNai().equals("Đã phản hồi")) {
                        textViewTrangThaiKhieuNai.setTextColor(Color.GREEN);
                        buttonPhanHoi.setText("Xem phản hồi");
                        buttonPhanHoi.setOnClickListener(view -> {
                            Intent intent = new Intent(this, ChiTietPhanHoiActivity.class);
                            intent.putExtra("MA_KHIEU_NAI", maKhieuNai);
                            intent.putExtra("CHI_TIET", chiTiet);
                            startActivityForResult(intent, 1);
                        });
                    }

                }
            }

        }
    }





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chi_tiet_khieu_nai);

        // Ánh xạ các thành phần giao diện
        textViewMaKhieuNai = findViewById(R.id.textViewMaKhieuNai);
//        textViewTenNguoiDung = findViewById(R.id.textViewTenNguoiDung);
        textViewDichVu = findViewById(R.id.textViewDichVu);
        textViewMoTaChiTiet = findViewById(R.id.textViewMoTaChiTiet);
        textViewNgayKhieuNai = findViewById(R.id.textViewNgayKhieuNai);
        textViewTrangThaiKhieuNai = findViewById(R.id.textViewTrangThaiKhieuNai);
//        textViewGoiYKhacPhuc = findViewById(R.id.textViewGoiYKhacPhuc);

        imageViewHinhAnh = findViewById(R.id.imageViewHinhAnh);
        buttonPhanHoi = findViewById(R.id.buttonPhanHoi);

        // Lấy dữ liệu từ Intent
        int maKhieuNai = getIntent().getIntExtra("MA_KHIEU_NAI", -1);

        if (maKhieuNai != -1) {
            // Lấy đối tượng KhieuNai từ cơ sở dữ liệu
            DBHelper dbHelper = new DBHelper(this);
            KhieuNai khieuNai = dbHelper.getKhieuNaiByID(maKhieuNai);

            if (khieuNai != null) {
                // Hiển thị thông tin trên giao diện
                textViewMaKhieuNai.setText(String.valueOf(khieuNai.getMaKhieuNai()));
                textViewDichVu.setText(khieuNai.getDichVu());
                textViewMoTaChiTiet.setText(khieuNai.getMoTaChiTiet());
                textViewNgayKhieuNai.setText(khieuNai.getNgayKhieuNai());
                textViewTrangThaiKhieuNai.setText(khieuNai.getTrangThaiKhieuNai());
//                textViewGoiYKhacPhuc.setText(khieuNai.getGoiYKhacPhuc());
                chiTiet = khieuNai.getMoTaChiTiet();


                if (khieuNai.getTrangThaiKhieuNai().equals("Đã phản hồi")) {
                    textViewTrangThaiKhieuNai.setTextColor(Color.GREEN);
                    buttonPhanHoi.setText("Xem phản hồi");

                    // Thêm hành động cho nút khi nhấn
                    buttonPhanHoi.setOnClickListener(view -> {
                        Intent intent = new Intent(this, ChiTietPhanHoiActivity.class);
                        intent.putExtra("MA_KHIEU_NAI", maKhieuNai);
                        intent.putExtra("CHI_TIET", chiTiet);
                        startActivityForResult(intent, 1);
                    });
                } else {
                    // Nếu trạng thái không phải "Đã phản hồi", thực hiện hành động bình thường
                    buttonPhanHoi.setOnClickListener(view -> {
                        Intent intent = new Intent(this, GuiPhanHoiActivity.class);
                        intent.putExtra("MA_KHIEU_NAI", maKhieuNai);
                        intent.putExtra("TIEU_DE", tieuDe);
                        intent.putExtra("CHI_TIET", chiTiet);
                        startActivityForResult(intent, 1); // 1 là mã yêu cầu
                    });
                }

                if (khieuNai.getHinhAnh() != null) {
                    displayImageFromBlob(khieuNai.getHinhAnh());
                }

            } else {
                tieuDe = "";
                chiTiet = "";
            }
        } else {
            tieuDe = "";
            chiTiet = "";

        }



    }



    private void displayImageFromBlob(byte[] blob) {

        Bitmap bitmap = BitmapFactory.decodeByteArray(blob, 0, blob.length);
        imageViewHinhAnh.setImageBitmap(bitmap);
    }


}
