package com.example.final_software.ProjectionManager;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.MenuItem;

import com.example.final_software.ProjectionManager.FragmentMain.ListDiaDiemChieuFragment;
import com.example.final_software.ProjectionManager.FragmentMain.ListPhimChieuFragment;
import com.example.final_software.ProjectionManager.FragmentMain.ListSanPhamFragment;
import com.example.final_software.ProjectionManager.FragmentMain.ListTheLoaiPhimFragment;
import com.example.final_software.ProjectionManager.FragmentMain.ListXuatChieuFragment;
import com.example.final_software.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;

public class HomeProjectionManagerActivity extends AppCompatActivity {
    BottomNavigationView bottom_nav;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_projection_manager);
        bottom_nav = findViewById(R.id.bottom_nav_pm);
        setFragment(new ListDiaDiemChieuFragment());
        bottom_nav.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                if(item.getItemId() == R.id.btm_nav_theloaiphim){
                    setFragment(new ListTheLoaiPhimFragment());
                    return true;
                }
                if(item.getItemId() == R.id.btm_nav_diadiemchieu){
                    setFragment(new ListDiaDiemChieuFragment());
                    return true;
                }
                if(item.getItemId() == R.id.btm_nav_phimchieu){
                    setFragment(new ListPhimChieuFragment());
                    return true;
                }
                if(item.getItemId() == R.id.btm_nav_xuatchieu){
                    setFragment(new ListXuatChieuFragment());
                    return true;
                }
                if(item.getItemId() == R.id.btm_nav_sanpham){
                    setFragment(new ListSanPhamFragment());
                    return true;
                }
                return false;
            }
        });
    }
    protected  void setFragment(Fragment fragment){
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.fragmentContainerView_pm, fragment);
        fragmentTransaction.commit();
    }
}